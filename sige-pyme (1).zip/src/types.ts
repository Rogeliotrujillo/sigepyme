export type Screen = 'login' | 'dashboard' | 'pos' | 'customers' | 'inventory' | 'reports' | 'settings';

export type TransitionType = 'push' | 'push_back' | 'slide_up' | 'none';

export interface Product {
  id: string;
  name: string;
  code: string;
  category: string;
  price: number;
  stock: number;
  minStock: number;
  maxStock?: number; // Stock máximo
  supplier?: string; // Proveedor
  image: string;
  demand?: 'Alta Demanda' | 'Bajo Stock' | 'Normal';
}

export interface Customer {
  id: string;
  name: string;
  cedula: string;
  phone: string;
  email: string;
  totalSpent: number;
  visits: number;
  averageTicket: number;
  frequentItems: Array<{ name: string; detail: string; isTop?: boolean }>;
  purchaseHistory: Array<{ date: string; invoice: string; amount: number; category: string; extraItemsCount?: number }>;
  status: 'VIP' | 'Deuda Pendiente' | 'Inactivo' | 'Normal';
  location: string;
}

export interface SaleItem {
  product: Product;
  quantity: number;
}

export interface Transaction {
  id: string;
  customerName: string;
  customerInitials: string;
  customerCedula?: string; // For Panamanian invoice
  date: string;
  amount: number;
  subtotal?: number;
  tax?: number;
  paymentMethod: 'Yappy' | 'Efectivo' | 'Tarjeta';
  status: 'Completado' | 'Pendiente';
  cashReceived?: number;
  changeGiven?: number;
  sellerRole?: string; // Role of the seller who processed it
}

export interface UserRole {
  id: string;
  username: string;
  name: string;
  role: 'Admin' | 'Gerente' | 'Vendedor';
  active: boolean;
}

export interface CompanyConfig {
  name: string;
  ruc: string;
  phone: string;
  email: string;
  address: string;
  logo?: string;
  itbmsRate: number; // e.g. 7 for 7%
  invoicePrefix: string;
  invoiceSequence: number;
}

