import React, { useState } from 'react';
import { Screen, TransitionType, Transaction, Product, Customer } from '../types';

interface ReportsProps {
  transactions: Transaction[];
  products: Product[];
  customers: Customer[];
  onNavigate: (target: Screen, transition?: TransitionType) => void;
}

type ReportTab = 'ventas' | 'inventario' | 'clientes' | 'financiero';

export default function Reports({ transactions, products, customers, onNavigate }: ReportsProps) {
  const [activeTab, setActiveTab] = useState<ReportTab>('ventas');
  const [dateFrom, setDateFrom] = useState('2026-07-01');
  const [dateTo, setDateTo] = useState('2026-07-09');

  // Interactive metrics calculation
  const totalVendido = transactions.reduce((acc, t) => acc + t.amount, 0);
  const totalITBMS = transactions.reduce((acc, t) => acc + (t.amount * 0.07 / 1.07), 0); // Simulated 7% ITBMS included
  const subtotalEstimado = totalVendido - totalITBMS;

  const totalProductos = products.reduce((acc, p) => acc + p.stock, 0);
  const productosBajoStock = products.filter(p => p.stock <= p.minStock).length;
  const productosSinStock = products.filter(p => p.stock === 0).length;

  const totalClientes = customers.length;
  const clientesVIP = customers.filter(c => c.status === 'VIP').length;
  const clientesInactivos = customers.filter(c => c.status === 'Inactivo').length;

  // Group transactions by payment method
  const yappySales = transactions.filter(t => t.paymentMethod === 'Yappy').reduce((acc, t) => acc + t.amount, 0);
  const cashSales = transactions.filter(t => t.paymentMethod === 'Efectivo').reduce((acc, t) => acc + t.amount, 0);
  const cardSales = transactions.filter(t => t.paymentMethod === 'Tarjeta').reduce((acc, t) => acc + t.amount, 0);

  // Group products by category
  const categoriesCount = products.reduce((acc: Record<string, number>, p) => {
    acc[p.category] = (acc[p.category] || 0) + p.stock;
    return acc;
  }, {});

  const handleExportExcel = () => {
    alert(`Exportando reporte de ${activeTab.toUpperCase()} en formato Excel (.xlsx) para el período del ${dateFrom} al ${dateTo}.`);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold text-on-background tracking-tight font-sans">Módulo de Reportes</h2>
          <p className="text-sm font-medium text-on-surface-variant mt-1 font-sans">Análisis avanzados, balances y estadísticas del negocio.</p>
        </div>
        <div className="flex items-center gap-3 w-full md:w-auto">
          <button
            onClick={handleExportExcel}
            className="flex-1 md:flex-none bg-white hover:bg-surface-container border border-outline-variant/60 text-on-surface px-4 py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm transition-all active:scale-95 cursor-pointer font-sans"
          >
            <span className="material-symbols-outlined text-[18px]">download</span>
            <span>Exportar Excel</span>
          </button>
          <button
            onClick={handlePrint}
            className="flex-1 md:flex-none bg-primary hover:bg-primary-container text-white px-4 py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-md shadow-primary/10 transition-all active:scale-95 cursor-pointer font-sans"
          >
            <span className="material-symbols-outlined text-[18px]">print</span>
            <span>Imprimir Reporte</span>
          </button>
        </div>
      </div>

      {/* Date Filter & Tab Selection Card */}
      <div className="bg-white border border-outline-variant/60 rounded-[24px] p-6 shadow-sm space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-outline-variant/40 pb-5">
          <div className="flex flex-wrap gap-1.5 bg-surface-container-low p-1 rounded-2xl border border-outline-variant/40">
            {(['ventas', 'inventario', 'clientes', 'financiero'] as const).map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all uppercase tracking-wider cursor-pointer font-sans ${
                  activeTab === tab
                    ? 'bg-primary text-white shadow-sm'
                    : 'text-on-surface-variant hover:text-on-surface hover:bg-surface-container'
                }`}
              >
                {tab === 'ventas' ? 'Ventas' : tab === 'inventario' ? 'Inventario' : tab === 'clientes' ? 'Clientes' : 'Financiero'}
              </button>
            ))}
          </div>

          {/* Date Filter Inputs */}
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 bg-slate-50 border border-outline-variant/50 rounded-xl px-3 py-2 text-xs">
              <span className="text-[10px] font-bold text-on-surface-variant uppercase font-sans">Desde:</span>
              <input
                type="date"
                value={dateFrom}
                onChange={e => setDateFrom(e.target.value)}
                className="bg-transparent text-on-surface font-semibold outline-none border-none cursor-pointer"
              />
            </div>
            <div className="flex items-center gap-1.5 bg-slate-50 border border-outline-variant/50 rounded-xl px-3 py-2 text-xs">
              <span className="text-[10px] font-bold text-on-surface-variant uppercase font-sans">Hasta:</span>
              <input
                type="date"
                value={dateTo}
                onChange={e => setDateTo(e.target.value)}
                className="bg-transparent text-on-surface font-semibold outline-none border-none cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Dynamic metrics based on Active Tab */}
        {activeTab === 'ventas' && (
          <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-primary/5 rounded-2xl p-5 border border-primary/10">
                <p className="text-[10px] font-bold text-primary uppercase tracking-wider font-sans">Monto Total Vendido</p>
                <p className="text-2xl font-black text-primary mt-1">${totalVendido.toFixed(2)}</p>
                <p className="text-[10px] text-on-surface-variant font-medium mt-1">Suma total de transacciones</p>
              </div>
              <div className="bg-tertiary/5 rounded-2xl p-5 border border-tertiary/10">
                <p className="text-[10px] font-bold text-tertiary uppercase tracking-wider font-sans">Transacciones Realizadas</p>
                <p className="text-2xl font-black text-tertiary mt-1">{transactions.length}</p>
                <p className="text-[10px] text-on-surface-variant font-medium mt-1">Ventas con factura generada</p>
              </div>
              <div className="bg-[#e8f5e9] rounded-2xl p-5 border border-[#c8e6c9]">
                <p className="text-[10px] font-bold text-[#2e7d32] uppercase tracking-wider font-sans">Ticket Promedio</p>
                <p className="text-2xl font-black text-[#2e7d32] mt-1">
                  ${transactions.length ? (totalVendido / transactions.length).toFixed(2) : '0.00'}
                </p>
                <p className="text-[10px] text-on-surface-variant font-medium mt-1">Valor promedio por cliente</p>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Left Chart: Sales Trends by Payment Method */}
              <div className="p-5 border border-outline-variant/50 rounded-2xl space-y-4">
                <h3 className="text-xs font-bold text-on-surface uppercase tracking-wider font-sans">Distribución por Método de Pago</h3>
                <div className="h-[200px] flex items-end gap-6 pt-4 pb-2 px-4 border-b border-outline-variant/30">
                  {/* Yappy Bar */}
                  <div className="flex-1 flex flex-col items-center group">
                    <div className="text-[10px] font-extrabold text-on-surface mb-2">${yappySales.toFixed(2)}</div>
                    <div className="w-full bg-blue-500 rounded-t-lg transition-all duration-300" style={{ height: `${totalVendido ? (yappySales / totalVendido) * 100 : 0}%`, minHeight: '10px' }}></div>
                    <span className="text-xs font-bold text-on-surface-variant mt-2 font-sans">Yappy</span>
                  </div>
                  {/* Cash Bar */}
                  <div className="flex-1 flex flex-col items-center group">
                    <div className="text-[10px] font-extrabold text-on-surface mb-2">${cashSales.toFixed(2)}</div>
                    <div className="w-full bg-green-500 rounded-t-lg transition-all duration-300" style={{ height: `${totalVendido ? (cashSales / totalVendido) * 100 : 0}%`, minHeight: '10px' }}></div>
                    <span className="text-xs font-bold text-on-surface-variant mt-2 font-sans">Efectivo</span>
                  </div>
                  {/* Card Bar */}
                  <div className="flex-1 flex flex-col items-center group">
                    <div className="text-[10px] font-extrabold text-on-surface mb-2">${cardSales.toFixed(2)}</div>
                    <div className="w-full bg-orange-500 rounded-t-lg transition-all duration-300" style={{ height: `${totalVendido ? (cardSales / totalVendido) * 100 : 0}%`, minHeight: '10px' }}></div>
                    <span className="text-xs font-bold text-on-surface-variant mt-2 font-sans">Tarjeta</span>
                  </div>
                </div>
              </div>

              {/* Right List: Recent transaction summary */}
              <div className="p-5 border border-outline-variant/50 rounded-2xl space-y-4">
                <h3 className="text-xs font-bold text-on-surface uppercase tracking-wider font-sans">Resumen del Período</h3>
                <div className="space-y-3 max-h-[220px] overflow-y-auto pr-1">
                  {transactions.map(t => (
                    <div key={t.id} className="flex justify-between items-center p-3 bg-slate-50 border border-outline-variant/30 rounded-xl">
                      <div>
                        <p className="text-xs font-bold text-on-surface font-sans">{t.customerName}</p>
                        <p className="text-[10px] text-on-surface-variant font-medium mt-0.5">{t.date} · {t.paymentMethod}</p>
                      </div>
                      <span className="text-xs font-black text-primary">${t.amount.toFixed(2)}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'inventario' && (
          <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-primary/5 rounded-2xl p-5 border border-primary/10">
                <p className="text-[10px] font-bold text-primary uppercase tracking-wider font-sans">Total Productos en Existencia</p>
                <p className="text-2xl font-black text-primary mt-1">{totalProductos} u.</p>
                <p className="text-[10px] text-on-surface-variant font-medium mt-1">Suma de stock físico de items</p>
              </div>
              <div className="bg-error/5 rounded-2xl p-5 border border-error/10">
                <p className="text-[10px] font-bold text-error uppercase tracking-wider font-sans">Productos en Alerta Crítica</p>
                <p className="text-2xl font-black text-error mt-1">{productosBajoStock}</p>
                <p className="text-[10px] text-on-surface-variant font-medium mt-1">Bajo el mínimo configurado</p>
              </div>
              <div className="bg-amber-500/5 rounded-2xl p-5 border border-amber-500/10">
                <p className="text-[10px] font-bold text-amber-600 uppercase tracking-wider font-sans">Productos Agotados</p>
                <p className="text-2xl font-black text-amber-600 mt-1">{productosSinStock}</p>
                <p className="text-[10px] text-on-surface-variant font-medium mt-1">Con existencias en cero (0)</p>
              </div>
            </div>

            {/* Graphical category stock overview */}
            <div className="p-5 border border-outline-variant/50 rounded-2xl space-y-4">
              <h3 className="text-xs font-bold text-on-surface uppercase tracking-wider font-sans">Existencias por Categoría</h3>
              <div className="space-y-3">
                {Object.entries(categoriesCount).map(([cat, qty]) => {
                  const maxQty = Math.max(...Object.values(categoriesCount));
                  const percent = maxQty ? (qty / maxQty) * 100 : 0;
                  return (
                    <div key={cat} className="space-y-1.5">
                      <div className="flex justify-between text-xs font-semibold text-on-surface font-sans">
                        <span>{cat}</span>
                        <span className="text-primary font-bold">{qty} unidades</span>
                      </div>
                      <div className="w-full h-3 bg-surface-container rounded-full overflow-hidden">
                        <div className="h-full bg-primary rounded-full" style={{ width: `${percent}%` }}></div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'clientes' && (
          <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-primary/5 rounded-2xl p-5 border border-primary/10">
                <p className="text-[10px] font-bold text-primary uppercase tracking-wider font-sans">Base de Clientes Registrados</p>
                <p className="text-2xl font-black text-primary mt-1">{totalClientes}</p>
                <p className="text-[10px] text-on-surface-variant font-medium mt-1">Fichas creadas en el sistema</p>
              </div>
              <div className="bg-tertiary/5 rounded-2xl p-5 border border-tertiary/10">
                <p className="text-[10px] font-bold text-tertiary uppercase tracking-wider font-sans">Clientes VIP</p>
                <p className="text-2xl font-black text-tertiary mt-1">{clientesVIP}</p>
                <p className="text-[10px] text-on-surface-variant font-medium mt-1">Con frecuencia alta y compras mayores</p>
              </div>
              <div className="bg-error/5 rounded-2xl p-5 border border-error/10">
                <p className="text-[10px] font-bold text-error uppercase tracking-wider font-sans">Clientes Inactivos</p>
                <p className="text-2xl font-black text-error mt-1">{clientesInactivos}</p>
                <p className="text-[10px] text-on-surface-variant font-medium mt-1">Sin visitas registradas recientemente</p>
              </div>
            </div>

            <div className="p-5 border border-outline-variant/50 rounded-2xl space-y-4">
              <h3 className="text-xs font-bold text-on-surface uppercase tracking-wider font-sans">Clientes con Mayor Nivel de Compra</h3>
              <div className="space-y-3">
                {customers.map(c => (
                  <div key={c.id} className="flex justify-between items-center p-3 bg-slate-50 border border-outline-variant/30 rounded-xl hover:border-primary/20 transition-all">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-xs">
                        {c.name.split(' ').map(n => n[0]).join('')}
                      </div>
                      <div>
                        <p className="text-xs font-bold text-on-surface font-sans">{c.name}</p>
                        <p className="text-[10px] text-on-surface-variant font-semibold mt-0.5">Visitas: {c.visits} · Ubicación: {c.location}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-xs font-black text-primary">${c.totalSpent.toFixed(2)}</span>
                      <p className="text-[9px] text-on-surface-variant font-semibold mt-0.5">Gastado</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'financiero' && (
          <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-[#e8f5e9] rounded-2xl p-5 border border-[#c8e6c9]">
                <p className="text-[10px] font-bold text-[#2e7d32] uppercase tracking-wider font-sans">Ingresos Totales Brutos</p>
                <p className="text-2xl font-black text-[#2e7d32] mt-1">${totalVendido.toFixed(2)}</p>
                <p className="text-[10px] text-on-surface-variant font-medium mt-1">Total de dinero recaudado</p>
              </div>
              <div className="bg-primary/5 rounded-2xl p-5 border border-primary/10">
                <p className="text-[10px] font-bold text-primary uppercase tracking-wider font-sans">Ingresos Netos Estimados</p>
                <p className="text-2xl font-black text-primary mt-1">${subtotalEstimado.toFixed(2)}</p>
                <p className="text-[10px] text-on-surface-variant font-medium mt-1">Excluyendo impuesto ITBMS</p>
              </div>
              <div className="bg-amber-500/5 rounded-2xl p-5 border border-amber-500/10">
                <p className="text-[10px] font-bold text-amber-700 uppercase tracking-wider font-sans">ITBMS Recaudado (7%)</p>
                <p className="text-2xl font-black text-amber-700 mt-1">${totalITBMS.toFixed(2)}</p>
                <p className="text-[10px] text-on-surface-variant font-medium mt-1">Impuesto aplicable DGI Panamá</p>
              </div>
            </div>

            <div className="p-6 bg-slate-50 border border-outline-variant/40 rounded-2xl space-y-4">
              <h3 className="text-xs font-bold text-on-surface uppercase tracking-wider font-sans">Balance Financiero Semanal (Panamá)</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-white border border-outline-variant/30 rounded-xl">
                  <span className="text-[10px] font-bold text-on-surface-variant uppercase font-sans">Secuencia de Facturación</span>
                  <p className="text-lg font-black text-on-surface font-sans mt-1">#INV-8832 a #INV-8848</p>
                </div>
                <div className="p-4 bg-white border border-outline-variant/30 rounded-xl">
                  <span className="text-[10px] font-bold text-on-surface-variant uppercase font-sans">Estado Tributario</span>
                  <p className="text-lg font-bold text-tertiary font-sans mt-1">Declarado / Regularizado</p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
