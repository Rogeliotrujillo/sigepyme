import React from 'react';
import { Screen, TransitionType, UserRole } from '../types';

interface SidebarProps {
  currentScreen: Screen;
  onNavigate: (target: Screen, transition?: TransitionType) => void;
  onLogout: () => void;
  currentUser: UserRole;
}

export default function Sidebar({ currentScreen, onNavigate, onLogout, currentUser }: SidebarProps) {
  const isVendedor = currentUser.role === 'Vendedor';

  const links = [
    { id: 'dashboard' as Screen, label: 'Dashboard Principal', icon: 'dashboard', allowed: true },
    { id: 'pos' as Screen, label: 'Nueva Venta (POS)', icon: 'point_of_sale', allowed: true },
    { id: 'customers' as Screen, label: 'Gestión de Clientes', icon: 'group', allowed: true },
    { id: 'inventory' as Screen, label: 'Gestión de Inventario', icon: 'inventory_2', allowed: !isVendedor },
    { id: 'reports' as Screen, label: 'Módulo de Reportes', icon: 'analytics', allowed: !isVendedor },
    { id: 'settings' as Screen, label: 'Configuración', icon: 'settings', allowed: !isVendedor },
  ];

  return (
    <aside className="h-screen w-64 fixed left-0 top-0 border-r border-outline-variant bg-white flex flex-col py-6 px-4 z-50 shadow-sm">
      {/* Brand Header */}
      <div className="flex items-center gap-3 px-2 mb-8">
        <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center text-white shadow-md shadow-primary/20">
          <span className="material-symbols-outlined text-[22px] !font-bold">dashboard</span>
        </div>
        <div>
          <h1 className="font-sans font-bold text-lg text-primary tracking-tight leading-none">SIGE-PYME</h1>
          <p className="text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mt-1">Gestión Comercial</p>
        </div>
      </div>

      {/* User Status Card */}
      <div className="bg-slate-50 border border-outline-variant/60 rounded-2xl p-3.5 mb-6 flex items-center gap-3">
        <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-xs shrink-0">
          {currentUser.name[0]}
        </div>
        <div className="min-w-0">
          <p className="text-xs font-extrabold text-on-surface truncate font-sans">{currentUser.name}</p>
          <div className="flex items-center gap-1.5 mt-0.5">
            <span className="w-1.5 h-1.5 rounded-full bg-green-500"></span>
            <span className="text-[9px] font-extrabold text-primary uppercase tracking-wide font-mono">{currentUser.role}</span>
          </div>
        </div>
      </div>

      {/* Navigation Links */}
      <nav className="flex-1 space-y-1">
        {links.map((link) => {
          const isActive = currentScreen === link.id;
          
          if (!link.allowed) {
            // Render locked item to clearly communicate permission restriction
            return (
              <div
                key={link.id}
                className="flex items-center justify-between py-2.5 px-4 rounded-xl text-on-surface-variant/40 bg-slate-100/40 select-none cursor-not-allowed"
                title="Este módulo requiere rol de Administrador o Gerente."
              >
                <div className="flex items-center gap-3">
                  <span className="material-symbols-outlined text-[20px]">{link.icon}</span>
                  <span className="font-sans text-xs font-semibold">{link.label}</span>
                </div>
                <span className="material-symbols-outlined text-[15px]">lock</span>
              </div>
            );
          }

          return (
            <a
              key={link.id}
              href="#"
              onClick={(e) => {
                e.preventDefault();
                onNavigate(link.id);
              }}
              className={`flex items-center gap-3 py-2.5 px-4 rounded-xl transition-all duration-200 group ${
                isActive
                  ? 'bg-primary text-white font-bold shadow-md shadow-primary/10'
                  : 'text-on-surface-variant hover:text-on-surface hover:bg-slate-100'
              }`}
            >
              <span className={`material-symbols-outlined text-[20px] transition-transform duration-200 group-hover:scale-105 ${isActive ? '!font-bold' : ''}`}>
                {link.icon}
              </span>
              <span className="font-sans text-xs font-semibold">{link.label}</span>
            </a>
          );
        })}
      </nav>

      {/* Footer support & logout */}
      <div className="mt-auto pt-4 border-t border-outline-variant/60 space-y-2">
        <button
          onClick={() => alert('Soporte Técnico SIGE-PYME: Canal de atención activo. En breve un asesor en Panamá le contactará.')}
          className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-primary/10 hover:bg-primary/15 text-primary rounded-xl text-xs font-bold transition-all active:scale-[0.97] cursor-pointer"
        >
          <span className="material-symbols-outlined text-[16px]">help</span>
          <span>Soporte Técnico</span>
        </button>

        <button
          onClick={(e) => {
            e.preventDefault();
            onLogout();
          }}
          className="w-full flex items-center gap-3 py-2.5 px-4 text-error hover:bg-error-container/20 rounded-xl transition-all text-xs font-bold cursor-pointer"
        >
          <span className="material-symbols-outlined text-[18px]">logout</span>
          <span className="font-sans">Cerrar Sesión</span>
        </button>
      </div>
    </aside>
  );
}
