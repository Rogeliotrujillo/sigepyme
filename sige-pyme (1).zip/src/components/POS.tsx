import React, { useState } from 'react';
import { Screen, TransitionType, Product, SaleItem, Transaction, Customer, CompanyConfig, UserRole } from '../types';

interface POSProps {
  products: Product[];
  customers: Customer[];
  companyConfig: CompanyConfig;
  currentUser: UserRole;
  onNavigate: (target: Screen, transition?: TransitionType) => void;
  onAddTransaction: (tx: Transaction) => void;
  onUpdateProductStock: (id: string, delta: number) => void;
  onAddCustomer: (customer: Customer) => void;
  onIncrementInvoiceSequence: () => void;
  onUpdateCustomerSpent: (id: string, amount: number) => void;
}

export default function POS({
  products,
  customers,
  companyConfig,
  currentUser,
  onNavigate,
  onAddTransaction,
  onUpdateProductStock,
  onAddCustomer,
  onIncrementInvoiceSequence,
  onUpdateCustomerSpent,
}: POSProps) {
  const [basket, setBasket] = useState<SaleItem[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('Todos');
  const [searchProductQuery, setSearchProductQuery] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<'Efectivo' | 'Yappy' | 'Tarjeta'>('Efectivo');
  const [showSuccessModal, setShowSuccessModal] = useState<boolean>(false);
  const [latestInvoice, setLatestInvoice] = useState<any>(null);

  // Cash calculation
  const [cashReceived, setCashReceived] = useState<string>('');
  
  // Customer selection
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [searchCustomerQuery, setSearchCustomerQuery] = useState<string>('');
  const [showCustomerModal, setShowCustomerModal] = useState<boolean>(false);

  // Quick Customer Creation Form
  const [newCustName, setNewCustName] = useState('');
  const [newCustCedula, setNewCustCedula] = useState('');
  const [newCustPhone, setNewCustPhone] = useState('');
  const [newCustEmail, setNewCustEmail] = useState('');

  const categories = ['Todos', 'Granos y Abarrotes', 'Lácteos y Quesos', 'Bebidas', 'Snacks', 'Limpieza', 'Electrónicos'];

  // Filter products by category and search
  const filteredProducts = products.filter(p => {
    const matchesCategory = selectedCategory === 'Todos' || p.category === selectedCategory;
    const matchesSearch = p.name.toLowerCase().includes(searchProductQuery.toLowerCase()) || 
                          p.code.toLowerCase().includes(searchProductQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleAddToBasket = (product: Product) => {
    if (product.stock <= 0) {
      alert('¡Este producto no tiene existencias disponibles en el inventario!');
      return;
    }

    const existingIndex = basket.findIndex(item => item.product.id === product.id);
    if (existingIndex > -1) {
      const currentQty = basket[existingIndex].quantity;
      if (currentQty >= product.stock) {
        alert(`Solo quedan ${product.stock} unidades de este producto en inventario.`);
        return;
      }
      const newBasket = [...basket];
      newBasket[existingIndex].quantity += 1;
      setBasket(newBasket);
    } else {
      setBasket([...basket, { product, quantity: 1 }]);
    }
  };

  const handleUpdateQty = (index: number, delta: number) => {
    const newBasket = [...basket];
    const newQty = newBasket[index].quantity + delta;

    if (newQty <= 0) {
      newBasket.splice(index, 1);
    } else {
      if (newQty > newBasket[index].product.stock) {
        alert(`No es posible agregar más de ${newBasket[index].product.stock} unidades de este producto.`);
        return;
      }
      newBasket[index].quantity = newQty;
    }
    setBasket(newBasket);
  };

  const handleClearBasket = () => {
    setBasket([]);
    setCashReceived('');
  };

  const subtotal = basket.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const taxRate = companyConfig.itbmsRate / 100;
  const tax = subtotal * taxRate; // Dynamic ITBMS rate
  const total = subtotal + tax;

  const cashReceivedNum = Number(cashReceived) || 0;
  const changeGiven = paymentMethod === 'Efectivo' && cashReceivedNum >= total ? cashReceivedNum - total : 0;

  const handleCreateCustomerQuick = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCustName || !newCustCedula) {
      alert('Por favor ingrese el Nombre y la Cédula/RUC del nuevo cliente.');
      return;
    }

    const newCustomer: Customer = {
      id: `c-${Date.now()}`,
      name: newCustName,
      cedula: newCustCedula,
      phone: newCustPhone || '+507 6000-0000',
      email: newCustEmail || `${newCustName.toLowerCase().replace(/\s+/g, '')}@gmail.pa`,
      totalSpent: 0,
      visits: 1,
      averageTicket: 0,
      frequentItems: [],
      purchaseHistory: [],
      status: 'Normal',
      location: 'Panamá',
    };

    onAddCustomer(newCustomer);
    setSelectedCustomer(newCustomer);
    setShowCustomerModal(false);
    setNewCustName('');
    setNewCustCedula('');
    setNewCustPhone('');
    setNewCustEmail('');
    alert('Cliente creado y seleccionado exitosamente en POS.');
  };

  const handleProcessSale = () => {
    if (basket.length === 0) {
      alert('El carrito está vacío. Agrega productos para procesar la venta.');
      return;
    }

    if (paymentMethod === 'Efectivo' && (!cashReceived || cashReceivedNum < total)) {
      alert(`Para pago en Efectivo, se requiere un monto recibido mínimo de $${total.toFixed(2)}`);
      return;
    }

    // Invoice Prefix and Sequence from dynamic config
    const orderNo = `${companyConfig.invoicePrefix}${companyConfig.invoiceSequence}`;
    const now = new Date();
    const formattedDate = `${now.getDate()} Jul, ${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')} ${now.getHours() >= 12 ? 'PM' : 'AM'}`;

    // Update stocks in app state
    basket.forEach(item => {
      onUpdateProductStock(item.product.id, -item.quantity);
    });

    const customerName = selectedCustomer ? selectedCustomer.name : 'Consumidor Final';
    const customerInitials = selectedCustomer
      ? selectedCustomer.name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase()
      : 'CF';

    // Update customer total spent
    if (selectedCustomer) {
      onUpdateCustomerSpent(selectedCustomer.id, total);
    }

    // Create transaction object
    const newTx: Transaction = {
      id: orderNo,
      customerName,
      customerInitials,
      customerCedula: selectedCustomer ? selectedCustomer.cedula : 'PE-8-8888',
      date: formattedDate,
      amount: total,
      subtotal,
      tax,
      paymentMethod: paymentMethod,
      status: 'Completado',
      cashReceived: paymentMethod === 'Efectivo' ? cashReceivedNum : undefined,
      changeGiven: paymentMethod === 'Efectivo' ? changeGiven : undefined,
      sellerRole: currentUser.role,
    };

    onAddTransaction(newTx);
    onIncrementInvoiceSequence();

    // Save for success dialog
    setLatestInvoice({
      orderNo,
      date: formattedDate,
      items: [...basket],
      subtotal,
      tax,
      total,
      paymentMethod,
      cashReceived: paymentMethod === 'Efectivo' ? cashReceivedNum : null,
      changeGiven: paymentMethod === 'Efectivo' ? changeGiven : null,
      customerName,
      customerCedula: selectedCustomer ? selectedCustomer.cedula : 'Consumidor Final',
    });

    setShowSuccessModal(true);
    setBasket([]);
    setCashReceived('');
    setSelectedCustomer(null);
  };

  // Filter customers for search dropdown
  const searchedCustomers = customers.filter(c => {
    const q = searchCustomerQuery.toLowerCase();
    return c.name.toLowerCase().includes(q) || c.cedula.toLowerCase().includes(q) || c.phone.toLowerCase().includes(q);
  });

  return (
    <div className="flex h-[calc(100vh-64px-40px)] gap-6 -mt-4 -mx-10 overflow-hidden bg-slate-50">
      {/* Left Panel: Product Selection */}
      <section className="flex-1 px-10 py-6 overflow-y-auto bg-slate-50 flex flex-col">
        <div className="mb-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h2 className="text-xl font-bold text-on-background font-sans leading-none">Punto de Venta (POS)</h2>
            <p className="text-xs font-medium text-on-surface-variant mt-1.5 font-sans">
              Busque y seleccione productos. Facturación con ITBMS ({companyConfig.itbmsRate}%) Panamá.
            </p>
          </div>

          {/* Product Search Box */}
          <div className="relative w-72">
            <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-on-surface-variant/70 text-[18px]">
              search
            </span>
            <input
              type="text"
              placeholder="Buscar por código o nombre..."
              value={searchProductQuery}
              onChange={e => setSearchProductQuery(e.target.value)}
              className="w-full bg-white border border-outline-variant/60 rounded-xl py-2 pl-9 pr-4 text-xs font-medium focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all font-sans"
            />
          </div>
        </div>

        {/* Category Filter Chips */}
        <div className="flex gap-1.5 overflow-x-auto pb-4 shrink-0">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer font-sans whitespace-nowrap border ${
                selectedCategory === cat
                  ? 'bg-primary border-primary text-white shadow-sm'
                  : 'bg-white border-outline-variant/50 text-on-surface-variant hover:text-on-surface hover:bg-surface-container'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6 overflow-y-auto flex-1 pr-1 pb-6">
          {filteredProducts.map(product => {
            const isOutOfStock = product.stock <= 0;
            return (
              <button
                key={product.id}
                onClick={() => handleAddToBasket(product)}
                disabled={isOutOfStock}
                className={`group bg-white rounded-2xl p-4 border border-outline-variant/50 hover:border-primary/40 text-left transition-all hover:-translate-y-1 hover:shadow-md focus:ring-2 focus:ring-primary/20 outline-none flex flex-col gap-3 h-full relative cursor-pointer ${
                  isOutOfStock ? 'opacity-60 cursor-not-allowed' : ''
                }`}
              >
                {/* Product Image */}
                <div className="aspect-[4/3] w-full rounded-xl overflow-hidden bg-surface-container relative">
                  <img
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    alt={product.name}
                    src={product.image}
                    referrerPolicy="no-referrer"
                  />
                  {isOutOfStock && (
                    <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                      <span className="text-white text-xs font-bold uppercase tracking-wider bg-error px-3 py-1 rounded-full">
                        Sin Stock
                      </span>
                    </div>
                  )}
                </div>

                <div className="flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-center">
                      <span className="text-[9px] font-mono text-on-surface-variant/80 uppercase">
                        {product.code}
                      </span>
                      <span className="text-[10px] font-bold text-on-surface-variant">Stock: {product.stock}</span>
                    </div>
                    <h3 className="text-xs font-bold text-on-surface mt-1.5 truncate font-sans group-hover:text-primary transition-colors">
                      {product.name}
                    </h3>
                  </div>
                  <div className="flex justify-between items-center mt-3">
                    <p className="text-primary font-extrabold text-base font-sans">${product.price.toFixed(2)}</p>
                    <span className="text-[9px] font-extrabold px-2 py-0.5 rounded-full uppercase bg-slate-100 text-slate-800">
                      {product.category}
                    </span>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* Right Panel: Receipt Panel */}
      <aside className="w-[400px] bg-white border-l border-outline-variant/60 flex flex-col h-full shadow-sm relative">
        <div className="p-6 flex justify-between items-center border-b border-outline-variant/60 bg-surface-container-low/20">
          <div>
            <h3 className="text-sm font-bold text-on-surface font-sans">Venta Activa</h3>
            <p className="text-[10px] font-semibold text-on-surface-variant font-mono mt-0.5 uppercase">
              SELLER: {currentUser.name} ({currentUser.role})
            </p>
          </div>
          <button
            onClick={handleClearBasket}
            className="text-error font-bold text-xs hover:bg-error-container/20 px-3 py-1.5 rounded-xl transition-colors cursor-pointer font-sans"
          >
            Vaciar Carrito
          </button>
        </div>

        {/* Customer Quick Search Selector */}
        <div className="p-4 border-b border-outline-variant/40 space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-[10px] font-extrabold text-on-surface-variant uppercase tracking-wider font-sans">
              Asignar Cliente (Opcional)
            </span>
            <button
              onClick={() => setShowCustomerModal(true)}
              className="text-primary font-extrabold text-[10px] uppercase hover:underline cursor-pointer"
            >
              + Nuevo Cliente
            </button>
          </div>

          <div className="relative">
            <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-on-surface-variant/70 text-[16px]">
              person_search
            </span>
            <input
              type="text"
              placeholder="Buscar cliente por nombre o cédula..."
              value={searchCustomerQuery}
              onChange={e => setSearchCustomerQuery(e.target.value)}
              className="w-full bg-slate-50 border border-outline-variant/50 rounded-xl py-2 pl-9 pr-8 text-xs font-medium focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all font-sans"
            />
            {searchCustomerQuery && (
              <button
                onClick={() => setSearchCustomerQuery('')}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-on-surface-variant"
              >
                <span className="material-symbols-outlined text-[16px]">close</span>
              </button>
            )}
          </div>

          {/* Search Results Dropdown */}
          {searchCustomerQuery && searchedCustomers.length > 0 && (
            <div className="absolute left-4 right-4 z-20 bg-white border border-outline-variant/80 rounded-xl shadow-xl max-h-48 overflow-y-auto divide-y divide-slate-100">
              {searchedCustomers.map(c => (
                <button
                  key={c.id}
                  onClick={() => {
                    setSelectedCustomer(c);
                    setSearchCustomerQuery('');
                  }}
                  className="w-full flex items-center justify-between p-3 hover:bg-slate-50 text-left"
                >
                  <div>
                    <p className="text-xs font-bold text-on-surface font-sans">{c.name}</p>
                    <p className="text-[10px] text-on-surface-variant font-mono mt-0.5">{c.cedula} · {c.phone}</p>
                  </div>
                  <span className="text-[9px] font-bold bg-primary/10 text-primary px-2 py-0.5 rounded">Select</span>
                </button>
              ))}
            </div>
          )}

          {/* Active Assigned Customer Tag */}
          {selectedCustomer ? (
            <div className="flex items-center justify-between bg-primary/5 border border-primary/25 rounded-xl p-3">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-full bg-primary text-white flex items-center justify-center font-bold text-[10px]">
                  {selectedCustomer.name.split(' ').map(n => n[0]).join('').substring(0,2).toUpperCase()}
                </div>
                <div>
                  <p className="text-xs font-bold text-primary font-sans leading-none">{selectedCustomer.name}</p>
                  <p className="text-[9px] text-on-surface-variant font-semibold mt-1">Cédula: {selectedCustomer.cedula}</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedCustomer(null)}
                className="text-error hover:bg-error/10 p-1 rounded-full transition-all"
              >
                <span className="material-symbols-outlined text-[18px]">delete</span>
              </button>
            </div>
          ) : (
            <div className="p-2.5 bg-slate-50 border border-dashed border-outline-variant/60 rounded-xl flex items-center justify-between">
              <span className="text-[11px] text-on-surface-variant font-sans font-medium">Consumidor Final (Por defecto)</span>
              <span className="text-[9px] font-bold bg-slate-200 text-slate-800 px-2 py-0.5 rounded uppercase font-mono">CF</span>
            </div>
          )}
        </div>

        {/* Basket Item list */}
        <div className="flex-grow overflow-y-auto p-4 space-y-3">
          {basket.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center text-on-surface-variant/50 py-12">
              <span className="material-symbols-outlined text-[48px] mb-2 opacity-40">shopping_basket</span>
              <p className="text-xs font-bold font-sans">El carrito está vacío</p>
              <p className="text-[10px] font-medium mt-1 font-sans max-w-[200px]">Selecciona productos de la izquierda para comenzar.</p>
            </div>
          ) : (
            basket.map((item, index) => (
              <div
                key={item.product.id}
                className="flex items-center gap-3 p-2.5 bg-slate-50 rounded-xl border border-outline-variant/40 transition-all duration-200"
              >
                <div className="flex-1 min-w-0">
                  <h4 className="text-xs font-bold text-on-surface truncate font-sans">{item.product.name}</h4>
                  <p className="text-[10px] text-on-surface-variant font-semibold font-sans mt-0.5">${item.product.price.toFixed(2)} c/u</p>
                </div>
                {/* Quantity Control */}
                <div className="flex items-center gap-1 bg-white rounded-lg p-0.5 shrink-0 border border-outline-variant/40">
                  <button
                    onClick={() => handleUpdateQty(index, -1)}
                    className="w-5 h-5 flex items-center justify-center hover:bg-slate-100 rounded font-bold text-xs transition-colors cursor-pointer"
                  >
                    -
                  </button>
                  <span className="text-xs font-extrabold w-4 text-center font-sans">{item.quantity}</span>
                  <button
                    onClick={() => handleUpdateQty(index, 1)}
                    className="w-5 h-5 flex items-center justify-center hover:bg-slate-100 rounded font-bold text-xs transition-colors cursor-pointer"
                  >
                    +
                  </button>
                </div>
                <div className="w-16 text-right font-extrabold text-primary text-xs shrink-0 font-sans">
                  ${(item.product.price * item.quantity).toFixed(2)}
                </div>
              </div>
            ))
          )}
        </div>

        {/* POS Calculation and Action Box */}
        <div className="p-6 bg-slate-50 border-t border-outline-variant/60">
          <div className="space-y-2 mb-4">
            <div className="flex justify-between text-xs font-semibold text-on-surface-variant font-sans">
              <span>Subtotal</span>
              <span className="font-bold text-on-surface">${subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-xs font-semibold text-on-surface-variant font-sans">
              <span>ITBMS ({companyConfig.itbmsRate}%)</span>
              <span className="font-bold text-on-surface">${tax.toFixed(2)}</span>
            </div>
            <div className="h-px bg-outline-variant/40 my-2"></div>
            <div className="flex justify-between font-bold text-base text-on-surface pt-1">
              <span className="font-sans">Total a Pagar</span>
              <span className="font-extrabold text-primary font-sans">${total.toFixed(2)}</span>
            </div>
          </div>

          {/* Payment Method Selector */}
          <div className="mb-4">
            <div className="grid grid-cols-3 gap-1.5">
              {(['Efectivo', 'Yappy', 'Tarjeta'] as const).map(method => {
                const isSelected = paymentMethod === method;
                return (
                  <button
                    key={method}
                    onClick={() => {
                      setPaymentMethod(method);
                      setCashReceived('');
                    }}
                    className={`flex flex-col items-center justify-center p-2 rounded-xl border transition-all cursor-pointer group ${
                      isSelected
                        ? 'border-primary bg-primary/5 text-primary'
                        : 'border-outline-variant/50 hover:border-outline-variant text-on-surface-variant'
                    }`}
                  >
                    <span className="material-symbols-outlined text-[16px] mb-0.5">
                      {method === 'Efectivo' ? 'payments' : method === 'Yappy' ? 'smartphone' : 'credit_card'}
                    </span>
                    <span className="text-[9px] font-bold font-sans">{method}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Cash received calculator for "Efectivo" method */}
          {paymentMethod === 'Efectivo' && (
            <div className="p-3 bg-white border border-outline-variant/40 rounded-xl space-y-2.5 mb-4">
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-extrabold text-on-surface-variant uppercase tracking-wider font-sans">
                  Monto Recibido
                </span>
                <span className="text-[10px] font-extrabold text-primary uppercase font-sans">
                  Total: ${total.toFixed(2)}
                </span>
              </div>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-on-surface-variant">
                  $
                </span>
                <input
                  type="number"
                  placeholder="0.00"
                  value={cashReceived}
                  onChange={e => setCashReceived(e.target.value)}
                  className="w-full bg-slate-50 border border-outline-variant/50 rounded-lg py-2 pl-6 pr-4 text-xs font-bold text-on-surface focus:outline-none font-sans"
                />
              </div>

              {cashReceivedNum > 0 && (
                <div className="flex justify-between items-center text-xs pt-1 border-t border-slate-100 font-sans">
                  <span className="font-semibold text-on-surface-variant">Vuelto a entregar:</span>
                  <span className={`font-extrabold ${changeGiven >= 0 ? 'text-green-700' : 'text-red-600'}`}>
                    {changeGiven >= 0 ? `$${changeGiven.toFixed(2)}` : `Faltan $${Math.abs(changeGiven).toFixed(2)}`}
                  </span>
                </div>
              )}
            </div>
          )}

          <button
            onClick={handleProcessSale}
            className="w-full bg-primary hover:bg-primary-container text-white py-3.5 rounded-xl font-bold text-sm hover:shadow-lg hover:shadow-primary/10 transition-all active:scale-[0.98] cursor-pointer shadow-md shadow-primary/5 font-sans"
          >
            Emitir Documento Fiscal
          </button>
        </div>
      </aside>

      {/* Quick Customer Creation Modal */}
      {showCustomerModal && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4 backdrop-blur-xs animate-fade-in">
          <div className="bg-white rounded-[24px] max-w-sm w-full p-6 border border-outline-variant shadow-2xl relative animate-in fade-in zoom-in-95 duration-250">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xs font-bold text-on-surface uppercase tracking-wider font-sans">Registrar Cliente Quick</h3>
              <button
                onClick={() => setShowCustomerModal(false)}
                className="w-7 h-7 rounded-full hover:bg-slate-100 flex items-center justify-center text-on-surface-variant transition-colors cursor-pointer"
              >
                <span className="material-symbols-outlined text-[18px]">close</span>
              </button>
            </div>

            <form onSubmit={handleCreateCustomerQuick} className="space-y-3.5">
              <div>
                <label className="block text-[9px] font-bold text-on-surface-variant uppercase tracking-wider mb-1 font-sans">
                  Nombre Completo
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ej. Juan Carlos"
                  value={newCustName}
                  onChange={e => setNewCustName(e.target.value)}
                  className="w-full bg-slate-50 border border-outline-variant/60 rounded-xl py-2 px-3 text-xs font-medium focus:ring-2 focus:ring-primary/10 focus:border-primary outline-none font-sans"
                />
              </div>

              <div>
                <label className="block text-[9px] font-bold text-on-surface-variant uppercase tracking-wider mb-1 font-sans">
                  Cédula / R.U.C. (Panamá)
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ej. 8-776-908"
                  value={newCustCedula}
                  onChange={e => setNewCustCedula(e.target.value)}
                  className="w-full bg-slate-50 border border-outline-variant/60 rounded-xl py-2 px-3 text-xs font-medium focus:ring-2 focus:ring-primary/10 focus:border-primary outline-none font-sans"
                />
              </div>

              <div>
                <label className="block text-[9px] font-bold text-on-surface-variant uppercase tracking-wider mb-1 font-sans">
                  Celular
                </label>
                <input
                  type="text"
                  placeholder="Ej. +507 6677-8822"
                  value={newCustPhone}
                  onChange={e => setNewCustPhone(e.target.value)}
                  className="w-full bg-slate-50 border border-outline-variant/60 rounded-xl py-2 px-3 text-xs font-medium focus:ring-2 focus:ring-primary/10 focus:border-primary outline-none font-sans"
                />
              </div>

              <div>
                <label className="block text-[9px] font-bold text-on-surface-variant uppercase tracking-wider mb-1 font-sans">
                  Email
                </label>
                <input
                  type="email"
                  placeholder="Ej. jcarlos@email.pa"
                  value={newCustEmail}
                  onChange={e => setNewCustEmail(e.target.value)}
                  className="w-full bg-slate-50 border border-outline-variant/60 rounded-xl py-2 px-3 text-xs font-medium focus:ring-2 focus:ring-primary/10 focus:border-primary outline-none font-sans"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-outline-variant/30">
                <button
                  type="button"
                  onClick={() => setShowCustomerModal(false)}
                  className="px-3.5 py-2 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg text-xs font-bold text-on-surface-variant"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-primary hover:bg-primary-container text-white rounded-lg text-xs font-bold"
                >
                  Registrar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Invoice Success Modal (DGI Panamá Standard Layout!) */}
      {showSuccessModal && latestInvoice && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-[24px] max-w-sm w-full p-5 border border-outline-variant shadow-2xl relative animate-in fade-in zoom-in-95 duration-200">
            <div className="flex flex-col items-center">
              {/* Success Ring */}
              <div className="w-11 h-11 bg-green-50 text-green-700 rounded-full flex items-center justify-center mb-3">
                <span className="material-symbols-outlined text-[24px] !font-bold">check_circle</span>
              </div>
              <h3 className="text-sm font-bold text-on-surface font-sans">FACTURACIÓN EXITOSA</h3>
              <p className="text-[10px] font-semibold text-on-surface-variant mt-0.5 tracking-wide uppercase">DGI Panamá Documento Autorizado</p>

              {/* Panamanian Standard Layout Ticket */}
              <div className="w-full bg-slate-50 rounded-2xl p-4 border border-outline-variant/50 mt-4 text-xs font-mono text-slate-800 space-y-3">
                <div className="text-center space-y-0.5 border-b border-dashed border-slate-300 pb-3">
                  <h4 className="font-extrabold font-sans text-xs uppercase tracking-tight text-on-surface">{companyConfig.name}</h4>
                  <p className="text-[9px] font-semibold text-on-surface-variant">RUC: {companyConfig.ruc}</p>
                  <p className="text-[9px] font-semibold text-on-surface-variant truncate max-w-[280px]">{companyConfig.address}</p>
                  <p className="text-[9px] font-semibold text-on-surface-variant">Tel: {companyConfig.phone} · {companyConfig.email}</p>
                </div>

                <div className="space-y-1.5 border-b border-dashed border-slate-300 pb-2 text-[10px]">
                  <div className="flex justify-between">
                    <span>DOCUMENTO:</span>
                    <span className="font-extrabold text-on-surface">{latestInvoice.orderNo}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>FECHA/HORA:</span>
                    <span>{latestInvoice.date}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>CLIENTE:</span>
                    <span className="font-bold truncate max-w-[150px]">{latestInvoice.customerName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>CÉDULA/RUC:</span>
                    <span>{latestInvoice.customerCedula}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>CAJERO:</span>
                    <span className="font-bold">{currentUser.name} ({currentUser.role})</span>
                  </div>
                </div>

                {/* Sales Items list */}
                <div className="space-y-1.5 border-b border-dashed border-slate-300 pb-2 max-h-[100px] overflow-y-auto">
                  {latestInvoice.items.map((item: SaleItem) => (
                    <div key={item.product.id} className="flex justify-between text-[10px] leading-tight">
                      <span className="truncate max-w-[180px]">
                        {item.product.name} ({item.product.code}) x{item.quantity}
                      </span>
                      <span className="font-bold text-on-surface">${(item.product.price * item.quantity).toFixed(2)}</span>
                    </div>
                  ))}
                </div>

                {/* Calculation Fields */}
                <div className="space-y-1 text-right text-[10px] border-b border-dashed border-slate-300 pb-2">
                  <div className="flex justify-between">
                    <span>SUBTOTAL:</span>
                    <span>${latestInvoice.subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>ITBMS ({companyConfig.itbmsRate}%):</span>
                    <span>${latestInvoice.tax.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between font-extrabold text-on-surface text-xs pt-0.5">
                    <span>TOTAL PAGADO:</span>
                    <span>${latestInvoice.total.toFixed(2)}</span>
                  </div>
                </div>

                {/* Cash received calculation or QR code for Yappy */}
                {latestInvoice.paymentMethod === 'Efectivo' && (
                  <div className="space-y-1 text-[10px] text-on-surface-variant font-sans border-b border-dashed border-slate-300 pb-2">
                    <div className="flex justify-between">
                      <span>Efectivo Recibido:</span>
                      <span className="font-bold text-on-surface">${latestInvoice.cashReceived?.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Vuelto Entregado:</span>
                      <span className="font-extrabold text-green-700">${latestInvoice.changeGiven?.toFixed(2)}</span>
                    </div>
                  </div>
                )}

                {latestInvoice.paymentMethod === 'Yappy' && (
                  <div className="flex flex-col items-center justify-center p-2.5 border border-dashed border-primary/40 rounded-xl bg-blue-50/40 text-center font-sans">
                    <span className="text-[9px] font-bold text-primary tracking-wide uppercase">Pago Confirmado vía Yappy</span>
                    <span className="material-symbols-outlined text-[36px] text-primary mt-1">qr_code_2</span>
                    <span className="text-[8px] text-on-surface-variant font-mono mt-0.5">Ref: BGPAM-{latestInvoice.orderNo}</span>
                  </div>
                )}

                <div className="text-center pt-1 font-sans text-[8px] text-on-surface-variant/80">
                  <p className="font-bold">P.A.C. AUTORIZADO - GRUPO SIGE-PYME</p>
                  <p className="mt-0.5">¡Gracias por su compra en Panamá!</p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-3.5 w-full mt-4">
                <button
                  onClick={() => alert(`Imprimiendo copia física de la factura ${latestInvoice.orderNo} en Panamá standard...`)}
                  className="py-2.5 bg-white border border-outline-variant/80 text-on-surface hover:bg-slate-50 rounded-xl text-xs font-bold transition-all active:scale-95 cursor-pointer flex items-center justify-center gap-1 font-sans"
                >
                  <span className="material-symbols-outlined text-[16px]">print</span>
                  <span>Imprimir</span>
                </button>
                <button
                  onClick={() => setShowSuccessModal(false)}
                  className="py-2.5 bg-primary hover:bg-primary-container text-white rounded-xl text-xs font-bold transition-all active:scale-95 cursor-pointer font-sans"
                >
                  Cerrar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
