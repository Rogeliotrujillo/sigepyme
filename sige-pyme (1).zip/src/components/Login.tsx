import React, { useState } from 'react';
import { UserRole } from '../types';

interface LoginProps {
  onLoginSuccess: (user: UserRole) => void;
  availableUsers: UserRole[];
}

export default function Login({ onLoginSuccess, availableUsers }: LoginProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!username || !password) {
      setError('Por favor, ingrese usuario y contraseña.');
      return;
    }

    // Standard credential mapping for high realism
    const user = availableUsers.find(
      u => u.username.toLowerCase() === username.toLowerCase() && u.active
    );

    if (user && password === `${user.username}123`) {
      onLoginSuccess(user);
    } else {
      setError('Credenciales inválidas. Intente con "admin" / "admin123", "gerente" / "gerente123" o "vendedor" / "vendedor123".');
    }
  };

  const handleQuickLogin = (user: UserRole) => {
    setUsername(user.username);
    setPassword(`${user.username}123`);
    onLoginSuccess(user);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6 relative overflow-hidden">
      {/* Dynamic background shapes */}
      <div className="absolute top-[-20%] left-[-10%] w-[500px] h-[500px] rounded-full bg-primary/5 blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-[600px] h-[600px] rounded-full bg-tertiary/5 blur-3xl pointer-events-none"></div>

      <div className="w-full max-w-md bg-white rounded-[32px] border border-outline-variant/60 shadow-xl overflow-hidden p-8 relative z-10">
        {/* Header Logo */}
        <div className="flex flex-col items-center text-center mb-8">
          <div className="w-14 h-14 bg-primary rounded-2xl flex items-center justify-center text-white shadow-lg shadow-primary/20 mb-4 animate-bounce">
            <span className="material-symbols-outlined text-[32px] !font-bold">dashboard</span>
          </div>
          <h1 className="font-sans font-black text-2xl text-primary tracking-tight">SIGE-PYME</h1>
          <p className="text-xs font-semibold text-on-surface-variant uppercase tracking-wider mt-1.5">
            Sistema de Gestión de Ventas e Inventario
          </p>
        </div>

        {/* Login Form */}
        <form onSubmit={handleLogin} className="space-y-5">
          {error && (
            <div className="p-4 bg-error-container/10 border border-error/20 rounded-2xl text-error text-xs font-bold font-sans flex items-center gap-2">
              <span className="material-symbols-outlined text-[18px]">error</span>
              <span>{error}</span>
            </div>
          )}

          <div>
            <label className="block text-[10px] font-extrabold text-on-surface-variant uppercase tracking-wider mb-2 font-sans">
              Nombre de Usuario
            </label>
            <div className="relative">
              <span className="material-symbols-outlined absolute left-3.5 top-1/2 -translate-y-1/2 text-on-surface-variant/70 text-[18px]">
                person
              </span>
              <input
                type="text"
                value={username}
                onChange={e => setUsername(e.target.value)}
                placeholder="Ej. admin, gerente, vendedor"
                className="w-full bg-surface-container-low border border-outline-variant/60 rounded-xl py-3 pl-11 pr-4 text-xs font-medium focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all font-sans"
              />
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-extrabold text-on-surface-variant uppercase tracking-wider mb-2 font-sans">
              Contraseña
            </label>
            <div className="relative">
              <span className="material-symbols-outlined absolute left-3.5 top-1/2 -translate-y-1/2 text-on-surface-variant/70 text-[18px]">
                lock
              </span>
              <input
                type="password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-surface-container-low border border-outline-variant/60 rounded-xl py-3 pl-11 pr-4 text-xs font-medium focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all font-sans"
              />
            </div>
            <p className="text-[10px] text-on-surface-variant/70 mt-1.5 text-right">
              Contraseña por defecto: <strong>nombreusuario123</strong>
            </p>
          </div>

          <button
            type="submit"
            className="w-full bg-primary hover:bg-primary-container text-white py-3.5 rounded-xl font-bold text-sm hover:shadow-lg hover:shadow-primary/10 transition-all active:scale-[0.98] cursor-pointer shadow-md shadow-primary/5 font-sans mt-2"
          >
            Iniciar Sesión
          </button>
        </form>

        {/* Quick Demo Access Roles */}
        <div className="mt-8 pt-6 border-t border-outline-variant/40">
          <p className="text-[10px] font-black text-on-surface-variant text-center uppercase tracking-wider mb-4 font-sans">
            Acceso Rápido de Prueba (Simulador)
          </p>
          <div className="grid grid-cols-3 gap-2.5">
            {availableUsers.map(user => (
              <button
                key={user.id}
                onClick={() => handleQuickLogin(user)}
                className="flex flex-col items-center justify-center p-3 bg-surface-container-low hover:bg-primary/5 border border-outline-variant/40 hover:border-primary/30 rounded-2xl transition-all cursor-pointer group"
              >
                <div className="w-10 h-10 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-xs group-hover:scale-105 transition-transform">
                  {user.role[0]}
                </div>
                <span className="text-[10px] font-bold text-on-surface mt-2 font-sans">{user.name}</span>
                <span className="text-[9px] font-semibold text-on-surface-variant font-mono mt-0.5">{user.role}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      <p className="text-xs text-on-surface-variant/60 font-sans mt-6">
        © 2026 SIGE-PYME Panamá · Gestión Empresarial de PYMEs
      </p>
    </div>
  );
}
