import React from 'react';
import { Screen, TransitionType, UserRole } from '../types';

interface HeaderProps {
  currentScreen: Screen;
  onNavigate: (target: Screen, transition?: TransitionType) => void;
  currentUser: UserRole;
  onLogout: () => void;
}

export default function Header({ currentScreen, onNavigate, currentUser, onLogout }: HeaderProps) {
  return (
    <header className="fixed top-0 right-0 left-64 h-16 z-40 bg-white/80 backdrop-blur-md border-b border-outline-variant/60 flex justify-between items-center px-10 transition-all duration-300">
      {/* Search and Navigation */}
      <div className="flex items-center gap-8 flex-1 max-w-xl">
        <div className="relative w-80">
          <span className="material-symbols-outlined absolute left-3.5 top-1/2 -translate-y-1/2 text-on-surface-variant/70 text-[20px]">
            search
          </span>
          <input
            type="text"
            placeholder="Buscar productos, clientes, facturas..."
            className="w-full bg-slate-50 border border-outline-variant/50 rounded-full py-1.5 pl-10 pr-4 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all font-sans"
          />
        </div>
        <div className="hidden lg:flex items-center gap-6">
          <a href="#" onClick={(e) => e.preventDefault()} className="text-primary font-bold text-xs pb-0.5 border-b-2 border-primary font-sans">
            Paneles activos
          </a>
          <a
            href="#"
            onClick={(e) => { e.preventDefault(); onNavigate('reports'); }}
            className="text-on-surface-variant hover:text-primary font-bold text-xs transition-colors font-sans"
          >
            Estadísticas
          </a>
        </div>
      </div>

      {/* Right Actions */}
      <div className="flex items-center gap-4">
        {/* Quick Sale button as specified by transition flow: slide_up to POS */}
        <button
          onClick={() => onNavigate('pos', 'slide_up')}
          className="bg-primary hover:bg-primary-container text-white px-5 py-2.5 rounded-xl text-xs font-bold hover:shadow-lg hover:shadow-primary/10 transition-all active:scale-95 flex items-center gap-1.5 cursor-pointer font-sans"
        >
          <span className="material-symbols-outlined text-[16px] !font-bold">add_circle</span>
          <span>Nueva Venta Quick</span>
        </button>

        {/* User Info / Avatar */}
        <div className="h-8 w-px bg-outline-variant/60 mx-1"></div>
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-xs border border-outline-variant/80 shadow-inner">
            {currentUser.name[0]}
          </div>
          <div className="hidden xl:block text-left">
            <p className="text-xs font-extrabold text-on-surface leading-tight">{currentUser.name}</p>
            <p className="text-[9px] text-primary font-bold uppercase tracking-wide mt-0.5">{currentUser.role} · Panamá</p>
          </div>
          
          {/* Quick inline logout */}
          <button
            onClick={onLogout}
            title="Cerrar Sesión"
            className="p-1 text-on-surface-variant hover:text-error hover:bg-error-container/20 rounded-lg transition-all ml-1 cursor-pointer"
          >
            <span className="material-symbols-outlined text-[18px]">logout</span>
          </button>
        </div>
      </div>
    </header>
  );
}
