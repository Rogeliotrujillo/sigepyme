import React, { useState } from 'react';
import { Screen, TransitionType, Customer } from '../types';

interface CustomersProps {
  customers: Customer[];
  onNavigate: (target: Screen, transition?: TransitionType) => void;
  onAddCustomer: (customer: Customer) => void;
}

export default function Customers({ customers, onNavigate, onAddCustomer }: CustomersProps) {
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('c-1');
  const [filter, setFilter] = useState<'All' | 'VIP' | 'Deuda Pendiente' | 'Inactivos'>('All');
  const [showAddModal, setShowAddModal] = useState<boolean>(false);

  // Form states for new customer
  const [name, setName] = useState('');
  const [cedula, setCedula] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [location, setLocation] = useState('Ciudad de Panamá');

  const selectedCustomer = customers.find(c => c.id === selectedCustomerId) || customers[0];

  const filteredCustomers = customers.filter(c => {
    if (filter === 'VIP') return c.status === 'VIP';
    if (filter === 'Deuda Pendiente') return c.status === 'Deuda Pendiente';
    if (filter === 'Inactivos') return c.status === 'Inactivo';
    return true;
  });

  const handleSelectCustomer = (id: string) => {
    setSelectedCustomerId(id);
  };

  const handleRegisterCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !cedula) {
      alert('Por favor ingresa al menos el Nombre y la Cédula.');
      return;
    }

    const initials = name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .substring(0, 2);

    const newCustomer: Customer = {
      id: `c-${Date.now()}`,
      name,
      cedula,
      phone: phone || '+507 6000-0000',
      email: email || `${name.toLowerCase().replace(/\s+/g, '')}@gmail.com`,
      totalSpent: 0,
      visits: 1,
      averageTicket: 0,
      frequentItems: [],
      purchaseHistory: [],
      status: 'Normal',
      location,
    };

    onAddCustomer(newCustomer);
    setSelectedCustomerId(newCustomer.id);
    setShowAddModal(false);

    // Reset fields
    setName('');
    setCedula('');
    setPhone('');
    setEmail('');
  };

  return (
    <div className="flex h-[calc(100vh-64px-40px)] gap-6 -mt-4 -mx-10 overflow-hidden bg-background">
      {/* Left Directory Side */}
      <div className="flex-grow flex flex-col min-w-0 px-10 py-6 overflow-y-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4 mb-6">
          <div>
            <h2 className="text-xl font-bold text-on-background font-sans leading-none">Gestión de Clientes</h2>
            <p className="text-xs font-medium text-on-surface-variant mt-1.5 font-sans">Administra tu base de datos y conoce los hábitos de tus compradores.</p>
          </div>
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 px-5 py-2.5 bg-primary hover:bg-primary-container text-white rounded-xl text-xs font-semibold shadow-md shadow-primary/10 transition-all active:scale-95 cursor-pointer font-sans"
          >
            <span className="material-symbols-outlined text-[16px] !font-bold">person_add</span>
            <span>Registrar Cliente</span>
          </button>
        </div>

        {/* Filter Stats Chips */}
        <div className="flex gap-2 mb-4 overflow-x-auto pb-1">
          <button
            onClick={() => setFilter('All')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-semibold cursor-pointer border transition-all ${
              filter === 'All'
                ? 'bg-primary/10 border-primary text-primary'
                : 'bg-white border-outline-variant/60 text-on-surface-variant hover:border-outline-variant'
            }`}
          >
            <span className="material-symbols-outlined text-[14px]">all_inclusive</span>
            <span>Todos ({customers.length})</span>
          </button>
          <button
            onClick={() => setFilter('VIP')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-semibold cursor-pointer border transition-all ${
              filter === 'VIP'
                ? 'bg-primary/10 border-primary text-primary'
                : 'bg-white border-outline-variant/60 text-on-surface-variant hover:border-outline-variant'
            }`}
          >
            <span className="material-symbols-outlined text-[14px]">star</span>
            <span>VIP ({customers.filter(c => c.status === 'VIP').length})</span>
          </button>
          <button
            onClick={() => setFilter('Deuda Pendiente')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-semibold cursor-pointer border transition-all ${
              filter === 'Deuda Pendiente'
                ? 'bg-primary/10 border-primary text-primary'
                : 'bg-white border-outline-variant/60 text-on-surface-variant hover:border-outline-variant'
            }`}
          >
            <span className="material-symbols-outlined text-[14px]">priority_high</span>
            <span>Deuda Pendiente ({customers.filter(c => c.status === 'Deuda Pendiente').length})</span>
          </button>
          <button
            onClick={() => setFilter('Inactivos')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-semibold cursor-pointer border transition-all ${
              filter === 'Inactivos'
                ? 'bg-primary/10 border-primary text-primary'
                : 'bg-white border-outline-variant/60 text-on-surface-variant hover:border-outline-variant'
            }`}
          >
            <span className="material-symbols-outlined text-[14px]">history</span>
            <span>Inactivos ({customers.filter(c => c.status === 'Inactivo').length})</span>
          </button>
        </div>

        {/* Customer Table Box */}
        <div className="flex-1 bg-white rounded-2xl border border-outline-variant/60 shadow-sm overflow-hidden flex flex-col">
          <div className="overflow-y-auto flex-grow">
            <table className="w-full text-left border-collapse">
              <thead className="sticky top-0 bg-surface-container-low text-on-surface-variant border-b border-outline-variant/50 z-10">
                <tr>
                  <th className="px-6 py-3 text-[10px] font-bold uppercase tracking-wider">Nombre</th>
                  <th className="px-6 py-3 text-[10px] font-bold uppercase tracking-wider">ID (Cédula)</th>
                  <th className="px-6 py-3 text-[10px] font-bold uppercase tracking-wider">Teléfono</th>
                  <th className="px-6 py-3 text-[10px] font-bold uppercase tracking-wider">Email</th>
                  <th className="px-6 py-3 text-[10px] font-bold uppercase tracking-wider text-right">Total Comprado ($)</th>
                  <th className="px-6 py-3 text-[10px] font-bold uppercase tracking-wider"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-outline-variant/40">
                {filteredCustomers.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-6 py-12 text-center text-on-surface-variant/60 font-sans text-xs">
                      No se encontraron clientes bajo esta categoría.
                    </td>
                  </tr>
                ) : (
                  filteredCustomers.map(customer => {
                    const initials = customer.name
                      .split(' ')
                      .map(n => n[0])
                      .join('')
                      .toUpperCase()
                      .substring(0, 2);
                    const isSelected = selectedCustomer?.id === customer.id;

                    return (
                      <tr
                        key={customer.id}
                        onClick={() => handleSelectCustomer(customer.id)}
                        className={`hover:bg-primary/5 transition-colors cursor-pointer group ${
                          isSelected ? 'bg-primary/5 border-l-4 border-primary' : ''
                        }`}
                      >
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full bg-surface-container text-on-surface-variant flex items-center justify-center font-extrabold text-xs">
                              {initials}
                            </div>
                            <span className="text-xs font-bold text-on-surface font-sans">{customer.name}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-xs font-medium text-on-surface-variant font-sans">{customer.cedula}</td>
                        <td className="px-6 py-4 text-xs font-medium text-on-surface-variant font-sans">{customer.phone}</td>
                        <td className="px-6 py-4 text-xs font-medium text-on-surface-variant font-sans">{customer.email}</td>
                        <td className="px-6 py-4 text-xs font-extrabold text-on-surface text-right font-sans">
                          ${customer.totalSpent.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </td>
                        <td className="px-6 py-4 text-right">
                          <span className="material-symbols-outlined text-outline/70 opacity-0 group-hover:opacity-100 transition-opacity text-[18px]">
                            chevron_right
                          </span>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>

          <div className="p-4 bg-surface-container-low/40 border-t border-outline-variant/50 flex justify-between items-center">
            <span className="text-[10px] font-bold text-on-surface-variant font-sans">
              Mostrando {filteredCustomers.length} de {customers.length} clientes
            </span>
            <div className="flex gap-1">
              <button className="p-1 hover:bg-surface-container rounded-lg transition-all">
                <span className="material-symbols-outlined text-[18px]">first_page</span>
              </button>
              <button className="p-1 hover:bg-surface-container rounded-lg transition-all">
                <span className="material-symbols-outlined text-[18px]">chevron_left</span>
              </button>
              <span className="px-2.5 py-1 text-xs font-bold bg-primary text-white rounded-lg">1</span>
              <button className="p-1 hover:bg-surface-container rounded-lg transition-all">
                <span className="material-symbols-outlined text-[18px]">chevron_right</span>
              </button>
              <button className="p-1 hover:bg-surface-container rounded-lg transition-all">
                <span className="material-symbols-outlined text-[18px]">last_page</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Right Detail Sidebar */}
      <aside
        id="customerDetail"
        className="w-[360px] bg-white border-l border-outline-variant/60 flex flex-col h-full shadow-sm"
      >
        {selectedCustomer ? (
          <>
            {/* Top overview card */}
            <div className="p-6 border-b border-outline-variant/60 bg-surface-container-low/20">
              <div className="flex justify-between items-start mb-4">
                <div className="w-14 h-14 rounded-2xl bg-primary text-white flex items-center justify-center font-extrabold text-lg shadow-md shadow-primary/25">
                  {selectedCustomer.name
                    .split(' ')
                    .map(n => n[0])
                    .join('')
                    .toUpperCase()
                    .substring(0, 2)}
                </div>
                <div className="flex gap-1">
                  <button
                    onClick={() => alert(`Editar cliente: ${selectedCustomer.name}`)}
                    className="p-2 text-on-surface-variant hover:bg-surface-container rounded-full transition-all cursor-pointer"
                  >
                    <span className="material-symbols-outlined text-[20px]">edit</span>
                  </button>
                  <button className="p-2 text-on-surface-variant hover:bg-surface-container rounded-full transition-all">
                    <span className="material-symbols-outlined text-[20px]">more_vert</span>
                  </button>
                </div>
              </div>
              <h3 className="text-base font-bold text-on-surface font-sans leading-snug">{selectedCustomer.name}</h3>
              <div className="flex items-center gap-1.5 mt-1.5">
                <span className={`px-2.5 py-0.5 rounded-full text-[9px] font-extrabold uppercase tracking-wider border ${
                  selectedCustomer.status === 'VIP' ? 'bg-primary/10 text-primary border-primary/15' :
                  selectedCustomer.status === 'Deuda Pendiente' ? 'bg-error-container/20 text-error border-error/15' :
                  'bg-surface-container text-on-surface-variant border-outline-variant/30'
                }`}>
                  Cliente {selectedCustomer.status}
                </span>
              </div>
              <div className="flex items-center gap-1 text-on-surface-variant mt-3">
                <span className="material-symbols-outlined text-[15px] text-primary/75">location_on</span>
                <span className="text-[11px] font-semibold font-sans">{selectedCustomer.location}</span>
              </div>
            </div>

            {/* Inner details scroller */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {/* Stats Grid */}
              <div className="grid grid-cols-2 gap-3.5">
                <div className="p-4 bg-surface-container-low/50 rounded-xl border border-outline-variant/20">
                  <p className="text-[10px] font-bold text-on-surface-variant uppercase tracking-wider font-sans">Visitas</p>
                  <p className="text-xl font-extrabold text-on-surface font-sans mt-1">{selectedCustomer.visits}</p>
                </div>
                <div className="p-4 bg-surface-container-low/50 rounded-xl border border-outline-variant/20">
                  <p className="text-[10px] font-bold text-on-surface-variant uppercase tracking-wider font-sans">Ticket Promedio</p>
                  <p className="text-xl font-extrabold text-on-surface font-sans mt-1">
                    ${selectedCustomer.averageTicket.toLocaleString('en-US', { minimumFractionDigits: 0 })}
                  </p>
                </div>
              </div>

              {/* Frequent Items */}
              <div>
                <h4 className="text-[10px] font-bold uppercase tracking-wider text-on-surface-variant mb-3 font-sans">Productos Frecuentes</h4>
                {selectedCustomer.frequentItems.length === 0 ? (
                  <p className="text-[11px] text-on-surface-variant/60 font-sans italic">Sin compras frecuentes registradas aún.</p>
                ) : (
                  <div className="space-y-2">
                    {selectedCustomer.frequentItems.map(item => (
                      <div
                        key={item.name}
                        className="flex items-center justify-between p-2.5 border border-outline-variant/40 rounded-xl hover:border-primary/35 transition-colors"
                      >
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 bg-surface-container rounded-lg flex items-center justify-center">
                            <span className="material-symbols-outlined text-primary text-[18px]">inventory</span>
                          </div>
                          <div>
                            <p className="text-xs font-bold text-on-surface font-sans leading-none">{item.name}</p>
                            <p className="text-[10px] text-on-surface-variant font-medium font-sans mt-1">{item.detail}</p>
                          </div>
                        </div>
                        {item.isTop && (
                          <span className="px-2 py-0.5 bg-tertiary-container/10 text-tertiary rounded-full text-[8px] font-bold tracking-wider">
                            TOP
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Purchase History Timeline */}
              <div>
                <div className="flex justify-between items-center mb-3">
                  <h4 className="text-[10px] font-bold uppercase tracking-wider text-on-surface-variant font-sans">Historial de Compras</h4>
                  <button
                    onClick={() => alert('Historial de facturación completo en camino...')}
                    className="text-primary hover:text-primary-container font-bold text-[10px] hover:underline cursor-pointer"
                  >
                    Ver Todo
                  </button>
                </div>

                {selectedCustomer.purchaseHistory.length === 0 ? (
                  <p className="text-[11px] text-on-surface-variant/60 font-sans italic">Sin historial de transacciones.</p>
                ) : (
                  <div className="space-y-4">
                    {selectedCustomer.purchaseHistory.map((item, idx) => (
                      <div key={item.invoice} className="relative pl-5 border-l-2 border-primary/10 space-y-1 pb-1">
                        {/* Dot indicator */}
                        <div className={`absolute -left-[6px] top-0 w-2.5 h-2.5 rounded-full ring-4 ring-white ${idx === 0 ? 'bg-primary' : 'bg-outline-variant'}`}></div>
                        <p className="text-[10px] font-semibold text-on-surface-variant font-sans">
                          {item.date} • {item.invoice}
                        </p>
                        <p className="text-xs font-extrabold text-on-surface font-sans">${item.amount.toFixed(2)}</p>
                        <div className="flex gap-1.5 pt-0.5">
                          <span className="px-2 py-0.5 bg-surface-container-high rounded text-[9px] font-semibold text-on-surface-variant">
                            {item.category}
                          </span>
                          {item.extraItemsCount && (
                            <span className="px-2 py-0.5 bg-surface-container-high rounded text-[9px] font-semibold text-on-surface-variant">
                              +{item.extraItemsCount} más
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Sticky Actions */}
            <div className="p-6 bg-surface-container-low/20 border-t border-outline-variant/60">
              <button
                onClick={() => alert(`Enviando estado de cuenta y facturas pendientes a ${selectedCustomer.email}...`)}
                className="w-full py-3 bg-white border border-primary text-primary hover:bg-primary hover:text-white font-bold rounded-xl text-xs transition-all active:scale-[0.98] shadow-sm cursor-pointer font-sans"
              >
                Enviar Factura Pendiente
              </button>
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center p-6 text-center text-on-surface-variant/50">
            <span className="material-symbols-outlined text-[48px] mb-2 opacity-40">person</span>
            <p className="text-xs font-bold">Selecciona un cliente</p>
            <p className="text-[10px] font-medium mt-1">Podrás ver su perfil y estado de cuenta.</p>
          </div>
        )}
      </aside>

      {/* Add Customer Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/65 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-[24px] max-w-md w-full p-6 border border-outline-variant shadow-2xl relative animate-in fade-in zoom-in-95 duration-200">
            <div className="flex justify-between items-center mb-5">
              <h3 className="text-sm font-bold text-on-surface font-sans">Registrar Nuevo Cliente</h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="w-8 h-8 rounded-full hover:bg-surface-container flex items-center justify-center text-on-surface-variant transition-colors cursor-pointer"
              >
                <span className="material-symbols-outlined text-[18px]">close</span>
              </button>
            </div>

            <form onSubmit={handleRegisterCustomer} className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1.5 font-sans">
                  Nombre Completo
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ej. Juan Pérez"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="w-full bg-surface-container-low border border-outline-variant/60 rounded-xl py-2 px-3 text-xs focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none font-sans"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1.5 font-sans">
                    ID / Cédula
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Ej. 8-888-888"
                    value={cedula}
                    onChange={e => setCedula(e.target.value)}
                    className="w-full bg-surface-container-low border border-outline-variant/60 rounded-xl py-2 px-3 text-xs focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none font-sans"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1.5 font-sans">
                    Teléfono
                  </label>
                  <input
                    type="text"
                    placeholder="Ej. +507 6666-6666"
                    value={phone}
                    onChange={e => setPhone(e.target.value)}
                    className="w-full bg-surface-container-low border border-outline-variant/60 rounded-xl py-2 px-3 text-xs focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none font-sans"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1.5 font-sans">
                  Email
                </label>
                <input
                  type="email"
                  placeholder="Ej. jperez@email.pa"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  className="w-full bg-surface-container-low border border-outline-variant/60 rounded-xl py-2 px-3 text-xs focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none font-sans"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1.5 font-sans">
                  Ubicación / Corregimiento
                </label>
                <input
                  type="text"
                  placeholder="Ej. San Francisco, Ciudad de Panamá"
                  value={location}
                  onChange={e => setLocation(e.target.value)}
                  className="w-full bg-surface-container-low border border-outline-variant/60 rounded-xl py-2 px-3 text-xs focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none font-sans"
                />
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-outline-variant/40 mt-5">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 bg-white hover:bg-surface-container border border-outline-variant/70 rounded-xl text-xs font-bold transition-all cursor-pointer font-sans text-on-surface-variant"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-primary hover:bg-primary-container text-white rounded-xl text-xs font-bold transition-all cursor-pointer font-sans shadow-md shadow-primary/10"
                >
                  Registrar Cliente
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
