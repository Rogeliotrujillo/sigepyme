import React, { useState } from 'react';
import { CompanyConfig, UserRole } from '../types';

interface SettingsProps {
  companyConfig: CompanyConfig;
  onUpdateCompanyConfig: (config: CompanyConfig) => void;
  users: UserRole[];
  onAddUser: (user: Omit<UserRole, 'id'>) => void;
  onToggleUserStatus: (id: string) => void;
  onUpdateUserRole: (id: string, role: 'Admin' | 'Gerente' | 'Vendedor') => void;
  currentUser: UserRole;
}

export default function Settings({
  companyConfig,
  onUpdateCompanyConfig,
  users,
  onAddUser,
  onToggleUserStatus,
  onUpdateUserRole,
  currentUser,
}: SettingsProps) {
  // Company details state
  const [compName, setCompName] = useState(companyConfig.name);
  const [compRuc, setCompRuc] = useState(companyConfig.ruc);
  const [compPhone, setCompPhone] = useState(companyConfig.phone);
  const [compEmail, setCompEmail] = useState(companyConfig.email);
  const [compAddress, setCompAddress] = useState(companyConfig.address);
  const [itbmsRate, setItbmsRate] = useState(companyConfig.itbmsRate);
  const [invPrefix, setInvPrefix] = useState(companyConfig.invoicePrefix);
  const [invSeq, setInvSeq] = useState(companyConfig.invoiceSequence);

  // Active payment methods
  const [activeYappy, setActiveYappy] = useState(true);
  const [activeEfectivo, setActiveEfectivo] = useState(true);
  const [activeTarjeta, setActiveTarjeta] = useState(true);

  // New user form
  const [newUsername, setNewUsername] = useState('');
  const [newName, setNewName] = useState('');
  const [newRole, setNewRole] = useState<'Admin' | 'Gerente' | 'Vendedor'>('Vendedor');

  const handleSaveCompany = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateCompanyConfig({
      name: compName,
      ruc: compRuc,
      phone: compPhone,
      email: compEmail,
      address: compAddress,
      itbmsRate: Number(itbmsRate),
      invoicePrefix: invPrefix,
      invoiceSequence: Number(invSeq),
    });
    alert('Configuración de la empresa guardada exitosamente.');
  };

  const handleCreateUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUsername || !newName) {
      alert('Por favor, complete todos los campos para el nuevo usuario.');
      return;
    }
    onAddUser({
      username: newUsername.trim().toLowerCase(),
      name: newName.trim(),
      role: newRole,
      active: true,
    });
    setNewUsername('');
    setNewName('');
    setNewRole('Vendedor');
    alert('Usuario creado exitosamente. Accede con la contraseña: ' + newUsername.trim().toLowerCase() + '123');
  };

  // Check if current user is Admin to allow user management edits
  const isAdmin = currentUser.role === 'Admin';

  return (
    <div className="space-y-8 pb-12">
      <div>
        <h2 className="text-3xl font-bold text-on-background tracking-tight font-sans">Configuración del Sistema</h2>
        <p className="text-sm font-medium text-on-surface-variant mt-1 font-sans">
          Administre la información de su empresa, usuarios, facturación y métodos de pago.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left 2 Cols: Forms */}
        <div className="lg:col-span-2 space-y-8">
          {/* Company Data & Billing Settings */}
          <div className="bg-white border border-outline-variant/60 rounded-[24px] p-6 shadow-sm space-y-6">
            <div className="flex items-center gap-3 border-b border-outline-variant/40 pb-4">
              <span className="material-symbols-outlined text-primary text-[28px]">domain</span>
              <h3 className="text-sm font-black text-on-surface uppercase tracking-wider font-sans">Datos de la Empresa y Facturación</h3>
            </div>

            <form onSubmit={handleSaveCompany} className="space-y-5">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div>
                  <label className="block text-[10px] font-extrabold text-on-surface-variant uppercase tracking-wider mb-2 font-sans">
                    Nombre del Comercio (Compañía)
                  </label>
                  <input
                    type="text"
                    value={compName}
                    onChange={e => setCompName(e.target.value)}
                    className="w-full bg-surface-container-low border border-outline-variant/50 rounded-xl py-2.5 px-4 text-xs font-semibold focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all font-sans"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-extrabold text-on-surface-variant uppercase tracking-wider mb-2 font-sans">
                    R.U.C. (Registro Único de Contribuyente)
                  </label>
                  <input
                    type="text"
                    value={compRuc}
                    onChange={e => setCompRuc(e.target.value)}
                    placeholder="Ej. 15562234-2-2023 DV 45"
                    className="w-full bg-surface-container-low border border-outline-variant/50 rounded-xl py-2.5 px-4 text-xs font-semibold focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all font-sans"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-extrabold text-on-surface-variant uppercase tracking-wider mb-2 font-sans">
                    Teléfono de Contacto
                  </label>
                  <input
                    type="text"
                    value={compPhone}
                    onChange={e => setCompPhone(e.target.value)}
                    className="w-full bg-surface-container-low border border-outline-variant/50 rounded-xl py-2.5 px-4 text-xs font-semibold focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all font-sans"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-extrabold text-on-surface-variant uppercase tracking-wider mb-2 font-sans">
                    Correo Electrónico
                  </label>
                  <input
                    type="email"
                    value={compEmail}
                    onChange={e => setCompEmail(e.target.value)}
                    className="w-full bg-surface-container-low border border-outline-variant/50 rounded-xl py-2.5 px-4 text-xs font-semibold focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all font-sans"
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-[10px] font-extrabold text-on-surface-variant uppercase tracking-wider mb-2 font-sans">
                    Dirección Física Completa (Panamá)
                  </label>
                  <input
                    type="text"
                    value={compAddress}
                    onChange={e => setCompAddress(e.target.value)}
                    className="w-full bg-surface-container-low border border-outline-variant/50 rounded-xl py-2.5 px-4 text-xs font-semibold focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all font-sans"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-5 pt-4 border-t border-outline-variant/40">
                <div>
                  <label className="block text-[10px] font-extrabold text-on-surface-variant uppercase tracking-wider mb-2 font-sans">
                    Tasa del ITBMS (%)
                  </label>
                  <input
                    type="number"
                    value={itbmsRate}
                    onChange={e => setItbmsRate(Number(e.target.value))}
                    className="w-full bg-surface-container-low border border-outline-variant/50 rounded-xl py-2.5 px-4 text-xs font-semibold focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all font-sans"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-extrabold text-on-surface-variant uppercase tracking-wider mb-2 font-sans">
                    Prefijo de Factura
                  </label>
                  <input
                    type="text"
                    value={invPrefix}
                    onChange={e => setInvPrefix(e.target.value)}
                    className="w-full bg-surface-container-low border border-outline-variant/50 rounded-xl py-2.5 px-4 text-xs font-semibold focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all font-sans"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-extrabold text-on-surface-variant uppercase tracking-wider mb-2 font-sans">
                    Siguiente Secuencia
                  </label>
                  <input
                    type="number"
                    value={invSeq}
                    onChange={e => setInvSeq(Number(e.target.value))}
                    className="w-full bg-surface-container-low border border-outline-variant/50 rounded-xl py-2.5 px-4 text-xs font-semibold focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all font-sans"
                  />
                </div>
              </div>

              <div className="flex justify-end pt-3">
                <button
                  type="submit"
                  className="bg-primary hover:bg-primary-container text-white px-6 py-3 rounded-xl text-xs font-bold shadow-md shadow-primary/10 transition-all active:scale-95 cursor-pointer font-sans flex items-center gap-2"
                >
                  <span className="material-symbols-outlined text-[18px]">save</span>
                  <span>Guardar Configuración</span>
                </button>
              </div>
            </form>
          </div>

          {/* User Role Management */}
          <div className="bg-white border border-outline-variant/60 rounded-[24px] p-6 shadow-sm space-y-6">
            <div className="flex items-center gap-3 border-b border-outline-variant/40 pb-4">
              <span className="material-symbols-outlined text-primary text-[28px]">group</span>
              <h3 className="text-sm font-black text-on-surface uppercase tracking-wider font-sans">Gestión de Usuarios y Roles</h3>
            </div>

            {!isAdmin && (
              <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-2xl text-amber-800 text-xs font-bold font-sans flex items-center gap-2">
                <span className="material-symbols-outlined text-[18px]">warning</span>
                <span>Modo de visualización limitado. Solo los usuarios con rol de <strong>Admin</strong> pueden crear o modificar usuarios.</span>
              </div>
            )}

            {isAdmin && (
              <form onSubmit={handleCreateUser} className="p-4 bg-slate-50 border border-outline-variant/40 rounded-2xl space-y-4">
                <h4 className="text-xs font-extrabold text-on-surface uppercase tracking-wider font-sans">Agregar Nuevo Colaborador</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-[9px] font-extrabold text-on-surface-variant uppercase tracking-wider mb-1.5 font-sans">
                      Nombre Completo
                    </label>
                    <input
                      type="text"
                      value={newName}
                      onChange={e => setNewName(e.target.value)}
                      placeholder="Ej. Juan Pérez"
                      className="w-full bg-white border border-outline-variant/50 rounded-xl py-2 px-3 text-xs font-medium focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none font-sans"
                    />
                  </div>
                  <div>
                    <label className="block text-[9px] font-extrabold text-on-surface-variant uppercase tracking-wider mb-1.5 font-sans">
                      Nombre de Usuario
                    </label>
                    <input
                      type="text"
                      value={newUsername}
                      onChange={e => setNewUsername(e.target.value)}
                      placeholder="Ej. jperez"
                      className="w-full bg-white border border-outline-variant/50 rounded-xl py-2 px-3 text-xs font-medium focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none font-sans"
                    />
                  </div>
                  <div>
                    <label className="block text-[9px] font-extrabold text-on-surface-variant uppercase tracking-wider mb-1.5 font-sans">
                      Rol de Usuario
                    </label>
                    <select
                      value={newRole}
                      onChange={e => setNewRole(e.target.value as 'Admin' | 'Gerente' | 'Vendedor')}
                      className="w-full bg-white border border-outline-variant/50 rounded-xl py-2 px-3 text-xs font-semibold focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none font-sans"
                    >
                      <option value="Admin">Administrador (Acceso total)</option>
                      <option value="Gerente">Gerente (Inventario y Ventas)</option>
                      <option value="Vendedor">Vendedor (Solo Ventas/POS)</option>
                    </select>
                  </div>
                </div>
                <div className="flex justify-end pt-1">
                  <button
                    type="submit"
                    className="bg-primary hover:bg-primary-container text-white px-5 py-2.5 rounded-xl text-xs font-bold shadow-sm transition-all active:scale-95 cursor-pointer font-sans flex items-center gap-1.5"
                  >
                    <span className="material-symbols-outlined text-[16px] !font-bold">add</span>
                    <span>Registrar Colaborador</span>
                  </button>
                </div>
              </form>
            )}

            {/* User List Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-outline-variant/40 text-[10px] font-extrabold text-on-surface-variant uppercase tracking-wider">
                    <th className="pb-3">Colaborador</th>
                    <th className="pb-3">Usuario</th>
                    <th className="pb-3">Rol</th>
                    <th className="pb-3">Estado</th>
                    {isAdmin && <th className="pb-3 text-right">Acciones</th>}
                  </tr>
                </thead>
                <tbody className="divide-y divide-outline-variant/20 text-xs font-medium text-on-surface">
                  {users.map(u => (
                    <tr key={u.id} className="hover:bg-slate-50/50">
                      <td className="py-4.5 font-bold font-sans">{u.name}</td>
                      <td className="py-4.5 font-mono text-on-surface-variant">{u.username}</td>
                      <td className="py-4.5">
                        {isAdmin ? (
                          <select
                            value={u.role}
                            onChange={e => onUpdateUserRole(u.id, e.target.value as 'Admin' | 'Gerente' | 'Vendedor')}
                            className="bg-transparent border border-outline-variant/40 rounded px-1.5 py-0.5 text-xs font-bold font-sans cursor-pointer focus:border-primary outline-none"
                          >
                            <option value="Admin">Admin</option>
                            <option value="Gerente">Gerente</option>
                            <option value="Vendedor">Vendedor</option>
                          </select>
                        ) : (
                          <span className="font-bold font-sans">{u.role}</span>
                        )}
                      </td>
                      <td className="py-4.5">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            u.active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                          }`}
                        >
                          {u.active ? 'Activo' : 'Inactivo'}
                        </span>
                      </td>
                      {isAdmin && (
                        <td className="py-4.5 text-right">
                          <button
                            onClick={() => onToggleUserStatus(u.id)}
                            disabled={u.id === currentUser.id}
                            className={`px-3 py-1.5 rounded-xl text-[10px] font-bold border cursor-pointer transition-all ${
                              u.active
                                ? 'border-red-200 text-red-600 hover:bg-red-50'
                                : 'border-green-200 text-green-600 hover:bg-green-50'
                            } disabled:opacity-40 disabled:pointer-events-none`}
                          >
                            {u.active ? 'Desactivar' : 'Activar'}
                          </button>
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Right Col: Payment Methods Status */}
        <div className="space-y-8">
          <div className="bg-white border border-outline-variant/60 rounded-[24px] p-6 shadow-sm space-y-6">
            <div className="flex items-center gap-3 border-b border-outline-variant/40 pb-4">
              <span className="material-symbols-outlined text-primary text-[28px]">payments</span>
              <h3 className="text-sm font-black text-on-surface uppercase tracking-wider font-sans">Métodos de Pago Habilitados</h3>
            </div>
            <p className="text-xs text-on-surface-variant font-medium font-sans">
              Active o desactive las opciones de pago que se mostrarán en la caja registradora (POS).
            </p>

            <div className="space-y-4">
              {/* Yappy */}
              <div className="flex items-center justify-between p-4 bg-slate-50 border border-outline-variant/30 rounded-2xl">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-blue-600 rounded-xl text-white flex items-center justify-center font-bold text-xs">
                    YP
                  </div>
                  <div>
                    <p className="text-xs font-bold text-on-surface font-sans">Yappy Banco General</p>
                    <p className="text-[10px] text-on-surface-variant font-medium mt-0.5">Transferencia QR Directa</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setActiveYappy(!activeYappy)}
                  className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                    activeYappy ? 'bg-primary' : 'bg-slate-300'
                  }`}
                >
                  <span
                    className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                      activeYappy ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              {/* Efectivo */}
              <div className="flex items-center justify-between p-4 bg-slate-50 border border-outline-variant/30 rounded-2xl">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-green-600 rounded-xl text-white flex items-center justify-center font-bold">
                    <span className="material-symbols-outlined text-[20px]">payments</span>
                  </div>
                  <div>
                    <p className="text-xs font-bold text-on-surface font-sans">Efectivo (USD / Balboas)</p>
                    <p className="text-[10px] text-on-surface-variant font-medium mt-0.5">Calculadora de vuelto activa</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setActiveEfectivo(!activeEfectivo)}
                  className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                    activeEfectivo ? 'bg-primary' : 'bg-slate-300'
                  }`}
                >
                  <span
                    className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                      activeEfectivo ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              {/* Tarjeta */}
              <div className="flex items-center justify-between p-4 bg-slate-50 border border-outline-variant/30 rounded-2xl">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-orange-600 rounded-xl text-white flex items-center justify-center font-bold">
                    <span className="material-symbols-outlined text-[20px]">credit_card</span>
                  </div>
                  <div>
                    <p className="text-xs font-bold text-on-surface font-sans">Tarjeta Crédito / Débito</p>
                    <p className="text-[10px] text-on-surface-variant font-medium mt-0.5">Visa, Mastercard, Clave</p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setActiveTarjeta(!activeTarjeta)}
                  className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                    activeTarjeta ? 'bg-primary' : 'bg-slate-300'
                  }`}
                >
                  <span
                    className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                      activeTarjeta ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
