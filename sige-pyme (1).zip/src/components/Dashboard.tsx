import React, { useState } from 'react';
import { Screen, TransitionType, Transaction, Product, Customer } from '../types';

interface DashboardProps {
  onNavigate: (target: Screen, transition?: TransitionType) => void;
  transactions: Transaction[];
  products?: Product[];
  customers?: Customer[];
  onAddTransactionClick?: () => void;
}

export default function Dashboard({ onNavigate, transactions, products = [], customers = [], onAddTransactionClick }: DashboardProps) {
  const [selectedDay, setSelectedDay] = useState<string>('Jue');
  const [selectedPeriod, setSelectedPeriod] = useState<string>('Últimos 7 días');

  // Dynamic Metrics based on state arrays
  const totalSalesValue = transactions.reduce((sum, tx) => sum + tx.amount, 0);
  const criticalStockCount = products.filter(p => p.stock <= p.minStock).length;
  const totalProductsCount = products.reduce((sum, p) => sum + p.stock, 0);
  const uniqueItemsCount = products.length;
  const customersCount = customers.length;

  // Last 7 days mock chart with some real value integrated
  const chartData = [
    { day: 'Lun', height: '40%', value: '$135.20' },
    { day: 'Mar', height: '65%', value: '$220.30' },
    { day: 'Mie', height: '55%', value: '$181.10' },
    { day: 'Jue', height: '85%', value: `$${totalSalesValue > 0 ? (totalSalesValue * 0.7).toFixed(2) : '342.50'}` },
    { day: 'Vie', height: '70%', value: `$${totalSalesValue > 0 ? (totalSalesValue * 0.9).toFixed(2) : '239.00'}` },
    { day: 'Sab', height: '45%', value: '$153.20' },
    { day: 'Dom', height: '30%', value: '$102.15' },
  ];

  // Derive top critical products for the alerts list
  const stockAlerts = products
    .filter(p => p.stock <= p.minStock)
    .slice(0, 3)
    .map(p => ({
      name: p.name,
      code: `SKU: ${p.code}`,
      qty: p.stock,
      min: p.minStock,
      image: p.image,
    }));

  return (
    <div className="space-y-8 pb-12 animate-in fade-in duration-200">
      {/* Welcome & Date Header */}
      <section className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div>
          <h2 className="text-3xl font-bold text-on-background tracking-tight font-sans">Panel de Control</h2>
          <p className="text-sm font-medium text-on-surface-variant mt-1 font-sans">
            Indicadores financieros y comerciales del Mini Super en tiempo real.
          </p>
        </div>
        <div className="flex items-center gap-3 w-full md:w-auto">
          <div className="flex items-center bg-white px-4 py-2.5 rounded-xl border border-outline-variant/60 shadow-sm text-xs font-bold text-on-surface-variant font-sans">
            <span className="material-symbols-outlined text-primary text-[18px] mr-2">calendar_today</span>
            <span>{new Date().toLocaleDateString('es-PA', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</span>
          </div>
          <button
            onClick={() => alert('Exportando resumen de operaciones de SIGE-PYME en formato PDF...')}
            className="bg-white hover:bg-slate-100 text-on-surface px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-1.5 border border-slate-200 shadow-sm transition-all active:scale-95 cursor-pointer font-sans"
          >
            <span className="material-symbols-outlined text-[18px]">download</span>
            <span>Exportar PDF</span>
          </button>
        </div>
      </section>

      {/* Summary Metrics (Bento Grid) */}
      <section className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {/* Total Sales Metric */}
        <div className="md:col-span-2 bg-primary rounded-[20px] p-6 text-white flex flex-col justify-between min-h-[170px] relative overflow-hidden shadow-lg shadow-primary/10">
          <div className="relative z-10 flex justify-between items-start">
            <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-sm">
              <span className="material-symbols-outlined text-white text-[24px]">payments</span>
            </div>
            <div className="flex items-center gap-1 bg-white/25 px-3 py-1 rounded-full backdrop-blur-sm text-[11px] font-bold text-white tracking-wider">
              <span className="material-symbols-outlined text-[14px]">trending_up</span>
              <span>+14.2%</span>
            </div>
          </div>
          <div className="relative z-10 mt-4">
            <p className="text-white/85 text-[11px] font-bold uppercase tracking-wider font-sans">Ventas de Hoy (Caja)</p>
            <h3 className="text-4xl font-extrabold tracking-tight mt-1 font-sans">
              ${totalSalesValue.toLocaleString('en-US', { minimumFractionDigits: 2 })}
            </h3>
          </div>
          <div className="absolute right-0 bottom-0 opacity-15 pointer-events-none translate-x-4 translate-y-4">
            <span className="material-symbols-outlined text-[180px]">show_chart</span>
          </div>
        </div>

        {/* Stock Status Card */}
        <div className="bg-white rounded-[20px] p-6 border border-outline-variant/60 shadow-sm flex flex-col justify-between min-h-[170px]">
          <div className="flex justify-between items-start">
            <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center">
              <span className="material-symbols-outlined text-on-surface-variant text-[24px]">inventory</span>
            </div>
            <span className={`text-[10px] font-extrabold px-3 py-1 rounded-full uppercase tracking-wider ${
              criticalStockCount > 2 ? 'bg-red-50 text-red-600' : 'bg-green-50 text-green-600'
            }`}>
              {criticalStockCount > 2 ? 'Atención Stock' : 'Estable'}
            </span>
          </div>
          <div className="mt-4">
            <p className="text-on-surface-variant text-[11px] font-bold uppercase tracking-wider font-sans">Productos en Existencia</p>
            <h3 className="text-3xl font-extrabold text-on-surface tracking-tight mt-1 font-sans">{totalProductsCount}</h3>
            <p className="text-[10px] text-on-surface-variant mt-1 font-sans font-semibold">En {uniqueItemsCount} referencias únicas</p>
          </div>
        </div>

        {/* New Customers Card */}
        <div className="bg-white rounded-[20px] p-6 border border-outline-variant/60 shadow-sm flex flex-col justify-between min-h-[170px]">
          <div className="flex justify-between items-start">
            <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center">
              <span className="material-symbols-outlined text-on-surface-variant text-[24px]">group</span>
            </div>
            <span className="text-primary text-[10px] font-extrabold bg-primary/10 px-3 py-1 rounded-full uppercase tracking-wider">
              {customersCount} Activos
            </span>
          </div>
          <div className="mt-4">
            <p className="text-on-surface-variant text-[11px] font-bold uppercase tracking-wider font-sans">Clientes Registrados</p>
            <h3 className="text-3xl font-extrabold text-on-surface tracking-tight mt-1 font-sans">{customersCount}</h3>
            <p className="text-[10px] text-on-surface-variant mt-1 font-sans font-semibold">Panameños con cédula / RUC</p>
          </div>
        </div>
      </section>

      {/* Middle Section: Alerts and Weekly Chart */}
      <section className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Sales Chart Panel */}
        <div className="lg:col-span-2 bg-white rounded-[20px] p-6 border border-outline-variant/60 shadow-sm flex flex-col">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h4 className="text-base font-bold text-on-surface font-sans">Rendimiento Semanal de Ventas</h4>
              <p className="text-xs text-on-surface-variant font-medium font-sans">Cierre de caja consolidado por día de la semana</p>
            </div>
            <select
              value={selectedPeriod}
              onChange={(e) => setSelectedPeriod(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold py-1.5 px-3 text-on-surface-variant outline-none cursor-pointer"
            >
              <option>Últimos 7 días</option>
              <option>Últimos 30 días</option>
            </select>
          </div>

          {/* Graphical Bars */}
          <div className="flex-1 min-h-[220px] flex items-end justify-between gap-3 px-2 pt-4 border-b border-outline-variant/40 pb-2">
            {chartData.map((data) => {
              const isHighlighted = selectedDay === data.day;
              return (
                <div
                  key={data.day}
                  onClick={() => setSelectedDay(data.day)}
                  className="flex-1 flex flex-col items-center group cursor-pointer"
                >
                  <div className={`text-[10px] font-extrabold px-2 py-0.5 rounded-md mb-2 transition-all duration-200 ${
                    selectedDay === data.day
                      ? 'bg-primary text-white scale-100 shadow-sm shadow-primary/25'
                      : 'bg-slate-100 text-on-surface-variant opacity-0 group-hover:opacity-100 scale-90 group-hover:scale-100'
                  }`}>
                    {data.value}
                  </div>

                  <div className="w-full relative bg-slate-100 rounded-t-lg overflow-hidden h-[150px] flex items-end">
                    <div
                      style={{ height: data.height }}
                      className={`w-full rounded-t-lg transition-all duration-300 ${
                        selectedDay === data.day
                          ? 'bg-primary shadow-md shadow-primary/20'
                          : 'bg-slate-300 group-hover:bg-primary/40'
                      }`}
                    ></div>
                  </div>

                  <span className={`block text-xs mt-2.5 transition-colors duration-200 ${
                    selectedDay === data.day
                      ? 'text-primary font-bold'
                      : 'text-on-surface-variant font-medium'
                  }`}>
                    {data.day}
                  </span>
                </div>
              );
            })}
          </div>

          <div className="flex justify-between items-center mt-3 text-[11px] text-on-surface-variant font-medium font-sans">
            <span>Día de mayor facturación: <strong className="text-primary">Jueves ({chartData.find(d => d.day === 'Jue')?.value})</strong></span>
            <span>Actualizado en tiempo real</span>
          </div>
        </div>

        {/* Stock Alerts Panel */}
        <div className="bg-white rounded-[20px] p-6 border border-outline-variant/60 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center mb-5">
              <div>
                <h4 className="text-base font-bold text-on-surface font-sans">Módulo de Alertas</h4>
                <p className="text-xs text-on-surface-variant font-medium font-sans">Repuestos y stock mínimo crítico</p>
              </div>
              <span className="bg-amber-100 text-amber-800 border border-amber-200 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider">
                {criticalStockCount} Críticos
              </span>
            </div>

            <div className="space-y-3">
              {stockAlerts.length === 0 ? (
                <div className="text-center py-10 text-on-surface-variant/60 text-xs font-sans">
                  No hay alertas críticas de stock. ¡Todo bajo control!
                </div>
              ) : (
                stockAlerts.map((alert) => (
                  <div
                    key={alert.name}
                    className="flex items-center gap-3 p-3 bg-red-50 hover:bg-red-100/60 rounded-xl border border-red-100 transition-colors"
                  >
                    <div className="w-11 h-11 rounded-lg bg-white overflow-hidden shrink-0 border border-slate-200">
                      <img className="w-full h-full object-cover" alt={alert.name} src={alert.image} referrerPolicy="no-referrer" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-bold text-on-surface truncate font-sans">{alert.name}</p>
                      <p className="text-[10px] font-medium text-on-surface-variant font-sans mt-0.5">{alert.code}</p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-red-600 font-extrabold text-xs font-sans">{alert.qty} u.</p>
                      <p className="text-[9px] font-bold text-on-surface-variant font-sans mt-0.5">Mín: {alert.min}</p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          <button
            onClick={() => onNavigate('inventory', 'push')}
            className="w-full mt-5 py-3 text-primary bg-primary/5 hover:bg-primary/10 rounded-xl text-xs font-bold transition-all active:scale-[0.98] border border-primary/10 hover:border-primary/25 cursor-pointer font-sans"
          >
            Ver Inventario Completo
          </button>
        </div>
      </section>

      {/* Recent Transactions Panel */}
      <section className="bg-white rounded-[20px] border border-outline-variant/60 shadow-sm overflow-hidden">
        <div className="px-6 py-5 border-b border-outline-variant/60 flex justify-between items-center bg-slate-50">
          <div>
            <h4 className="text-base font-bold text-on-surface font-sans">Transacciones del Turno</h4>
            <p className="text-xs text-on-surface-variant font-medium font-sans">Historial de ventas recientes en el punto de venta</p>
          </div>
          <button
            onClick={() => onNavigate('reports')}
            className="text-primary hover:text-primary-container font-bold text-xs flex items-center gap-1 hover:underline cursor-pointer font-sans"
          >
            <span>Ver reporte extendido</span>
            <span className="material-symbols-outlined text-[16px] !font-bold">chevron_right</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead className="bg-slate-100/50 border-b border-slate-200">
              <tr>
                <th className="px-6 py-3 text-[10px] font-bold text-on-surface-variant uppercase tracking-wider">Factura N°</th>
                <th className="px-6 py-3 text-[10px] font-bold text-on-surface-variant uppercase tracking-wider">Cliente</th>
                <th className="px-6 py-3 text-[10px] font-bold text-on-surface-variant uppercase tracking-wider">Fecha & Hora</th>
                <th className="px-6 py-3 text-[10px] font-bold text-on-surface-variant uppercase tracking-wider text-right">Monto</th>
                <th className="px-6 py-3 text-[10px] font-bold text-on-surface-variant uppercase tracking-wider">Método de Pago</th>
                <th className="px-6 py-3 text-[10px] font-bold text-on-surface-variant uppercase tracking-wider">Estado DGI</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {transactions.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-8 text-center text-on-surface-variant/60 text-xs font-sans">
                    No se han registrado ventas en este turno.
                  </td>
                </tr>
              ) : (
                transactions.map((tx) => (
                  <tr key={tx.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4 text-xs font-mono font-bold text-primary">{tx.id}</td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-xs tracking-tight shadow-sm">
                          {tx.customerInitials || 'CF'}
                        </div>
                        <span className="text-xs font-bold text-on-surface font-sans">{tx.customerName}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-xs font-medium text-on-surface-variant font-sans">{tx.date}</td>
                    <td className="px-6 py-4 text-right text-xs font-extrabold text-on-surface font-sans">${tx.amount.toFixed(2)}</td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-1.5 text-xs font-semibold text-on-surface">
                        <span className={`w-1.5 h-1.5 rounded-full ${
                          tx.paymentMethod === 'Yappy' ? 'bg-sky-500' :
                          tx.paymentMethod === 'Efectivo' ? 'bg-green-500' : 'bg-amber-500'
                        }`}></span>
                        <span className="font-sans">{tx.paymentMethod}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="px-2.5 py-1 rounded-full text-[9px] font-extrabold uppercase tracking-wider bg-green-100 text-green-800 border border-green-200">
                        {tx.status || 'Completado'}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
