import React, { useState } from 'react';
import { Screen, TransitionType, Product } from '../types';

interface InventoryProps {
  products: Product[];
  onNavigate: (target: Screen, transition?: TransitionType) => void;
  onAddProduct: (product: Product) => void;
  onDeleteProduct: (id: string) => void;
  onUpdateProduct: (product: Product) => void;
}

export default function Inventory({
  products,
  onNavigate,
  onAddProduct,
  onDeleteProduct,
  onUpdateProduct,
}: InventoryProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('Todas');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [showEditModal, setShowEditModal] = useState<boolean>(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Form states for adding/editing product
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [category, setCategory] = useState('Granos y Abarrotes');
  const [price, setPrice] = useState<number>(0);
  const [stock, setStock] = useState<number>(0);
  const [minStock, setMinStock] = useState<number>(10);
  const [maxStock, setMaxStock] = useState<number>(100);
  const [supplier, setSupplier] = useState('');
  const [image, setImage] = useState('');

  const categories = ['Todas', 'Granos y Abarrotes', 'Lácteos y Quesos', 'Bebidas', 'Snacks', 'Limpieza', 'Electrónicos'];

  const filteredProducts = products.filter(p => {
    const matchesCategory = selectedCategory === 'Todas' || p.category === selectedCategory;
    const matchesSearch =
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (p.supplier && p.supplier.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  const totalInventoryValue = products.reduce((sum, p) => sum + p.price * p.stock, 0);

  const handleOpenAddModal = () => {
    setName('');
    setCode(`PD-${Math.floor(1000 + Math.random() * 9000)}`);
    setCategory('Granos y Abarrotes');
    setPrice(0);
    setStock(0);
    setMinStock(10);
    setMaxStock(100);
    setSupplier('');
    setImage('');
    setShowAddModal(true);
  };

  const handleCreateProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || price <= 0) {
      alert('Por favor ingresa un nombre y un precio válido.');
      return;
    }

    const defaultImages: Record<string, string> = {
      'Granos y Abarrotes': 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&q=80&w=150',
      'Lácteos y Quesos': 'https://images.unsplash.com/photo-1486299267070-8382e214439b?auto=format&fit=crop&q=80&w=150',
      'Bebidas': 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?auto=format&fit=crop&q=80&w=150',
      'Snacks': 'https://images.unsplash.com/photo-1599490659213-e2b9527bb087?auto=format&fit=crop&q=80&w=150',
      'Limpieza': 'https://images.unsplash.com/photo-1583947215259-38e31be8751f?auto=format&fit=crop&q=80&w=150',
      'Electrónicos': 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?auto=format&fit=crop&q=80&w=150',
    };

    const newProduct: Product = {
      id: `p-${Date.now()}`,
      name,
      code,
      category,
      price,
      stock,
      minStock,
      maxStock,
      supplier: supplier || 'Proveedor Local',
      image: image || defaultImages[category] || 'https://images.unsplash.com/photo-1531403009284-440f080d1e12?auto=format&fit=crop&q=80&w=150',
      demand: stock <= minStock ? 'Bajo Stock' : (stock > 50 ? 'Alta Demanda' : 'Normal'),
    };

    onAddProduct(newProduct);
    setShowAddModal(false);
  };

  const handleOpenEditModal = (product: Product) => {
    setEditingProduct(product);
    setName(product.name);
    setCode(product.code);
    setCategory(product.category);
    setPrice(product.price);
    setStock(product.stock);
    setMinStock(product.minStock);
    setMaxStock(product.maxStock || 100);
    setSupplier(product.supplier || '');
    setImage(product.image);
    setShowEditModal(true);
  };

  const handleSaveEditProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct) return;

    const updatedProduct: Product = {
      ...editingProduct,
      name,
      code,
      category,
      price,
      stock,
      minStock,
      maxStock,
      supplier,
      image,
      demand: stock <= minStock ? 'Bajo Stock' : (stock > 50 ? 'Alta Demanda' : 'Normal'),
    };

    onUpdateProduct(updatedProduct);
    setShowEditModal(false);
    setEditingProduct(null);
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold text-on-background tracking-tight font-sans">Gestión de Inventario</h2>
          <p className="text-sm font-medium text-on-surface-variant mt-1 font-sans">
            Supervise, actualice y controle las existencias de productos en tiempo real.
          </p>
        </div>
        <button
          onClick={handleOpenAddModal}
          className="bg-primary hover:bg-primary-container text-white flex items-center gap-2 px-5 py-3 rounded-xl shadow-lg hover:shadow-primary/20 hover:scale-[1.01] active:scale-95 transition-all font-bold text-xs cursor-pointer font-sans"
        >
          <span className="material-symbols-outlined text-[18px] !font-bold">add</span>
          <span>Añadir Producto</span>
        </button>
      </div>

      {/* Bento Grid: Category Filter, Search & stats */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Category & Search Filter Card */}
        <div className="lg:col-span-8 bg-white border border-outline-variant/60 rounded-2xl p-5 shadow-sm space-y-4">
          <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
            <div>
              <p className="text-[10px] font-bold text-on-surface-variant uppercase tracking-wider font-sans">
                Filtrar por Categoría
              </p>
            </div>
            {/* Search input inside inventory list */}
            <div className="relative w-full md:w-64">
              <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-on-surface-variant/70 text-[18px]">
                search
              </span>
              <input
                type="text"
                placeholder="Buscar por código, nombre o proveedor..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full bg-slate-50 border border-outline-variant/60 rounded-xl py-1.5 pl-9 pr-4 text-xs font-medium focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all font-sans"
              />
            </div>
          </div>

          <div className="flex flex-wrap gap-1.5">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer font-sans ${
                  selectedCategory === cat
                    ? 'bg-primary text-white shadow-sm'
                    : 'bg-slate-100 text-on-surface-variant hover:bg-slate-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Total inventory Value */}
        <div className="lg:col-span-4 bg-primary text-white rounded-2xl p-5 shadow-lg shadow-primary/10 flex flex-col justify-center relative overflow-hidden">
          <div className="relative z-10">
            <p className="text-white/80 text-[10px] font-bold uppercase tracking-wider font-sans">Valor Total Inventario</p>
            <h3 className="text-2xl font-extrabold tracking-tight mt-1 font-sans">
              ${totalInventoryValue.toLocaleString('en-US', { minimumFractionDigits: 2 })}
            </h3>
            <p className="text-white/70 text-[9px] mt-1.5 font-sans font-semibold">Valor monetario estimado de existencias</p>
          </div>
          <div className="absolute -right-4 -bottom-4 opacity-15 pointer-events-none">
            <span className="material-symbols-outlined text-[100px]">inventory</span>
          </div>
        </div>
      </div>

      {/* Table Card */}
      <div className="bg-white border border-outline-variant/60 rounded-2xl shadow-sm overflow-hidden">
        {/* Actions header bar */}
        <div className="p-5 border-b border-outline-variant/60 flex justify-between items-center bg-surface-container-low/20">
          <div className="flex items-center gap-3">
            <span className="text-sm font-bold text-on-surface font-sans">Catálogo de Productos</span>
            <span className="bg-primary/10 text-primary text-[10px] px-2.5 py-0.5 rounded-full font-extrabold uppercase tracking-wider">
              {filteredProducts.length} Ítems
            </span>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => alert('Filtros avanzados de stock cargados...')}
              className="p-2 border border-outline-variant/60 rounded-lg text-on-surface-variant hover:bg-surface-container transition-all cursor-pointer"
            >
              <span className="material-symbols-outlined text-[18px]">filter_list</span>
            </button>
            <button
              onClick={() => alert('Exportando inventario actual de SIGE-PYME en formato Excel...')}
              className="p-2 border border-outline-variant/60 rounded-lg text-on-surface-variant hover:bg-surface-container transition-all cursor-pointer"
            >
              <span className="material-symbols-outlined text-[18px]">download</span>
            </button>
          </div>
        </div>

        {/* Table Body */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead className="bg-surface-container-low/50 border-b border-outline-variant/40">
              <tr>
                <th className="px-6 py-3 text-[10px] font-bold uppercase text-on-surface-variant tracking-wider">Código SKU</th>
                <th className="px-6 py-3 text-[10px] font-bold uppercase text-on-surface-variant tracking-wider">Producto</th>
                <th className="px-6 py-3 text-[10px] font-bold uppercase text-on-surface-variant tracking-wider">Categoría</th>
                <th className="px-6 py-3 text-[10px] font-bold uppercase text-on-surface-variant tracking-wider">Proveedor</th>
                <th className="px-6 py-3 text-[10px] font-bold uppercase text-on-surface-variant tracking-wider text-right">Precio</th>
                <th className="px-6 py-3 text-[10px] font-bold uppercase text-on-surface-variant tracking-wider text-center">Stock / Máx</th>
                <th className="px-6 py-3 text-[10px] font-bold uppercase text-on-surface-variant tracking-wider">Estado</th>
                <th className="px-6 py-3 text-[10px] font-bold uppercase text-on-surface-variant tracking-wider text-right">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-outline-variant/40">
              {filteredProducts.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-6 py-12 text-center text-on-surface-variant/60 font-sans text-xs">
                    No se encontraron productos en esta consulta de inventario.
                  </td>
                </tr>
              ) : (
                filteredProducts.map(product => {
                  let stockStatus = 'En Stock';
                  let statusColor = 'bg-green-100 text-green-800 border-green-200';
                  let statusDot = 'bg-green-600';

                  if (product.stock === 0) {
                    stockStatus = 'Agotado';
                    statusColor = 'bg-red-100 text-red-800 border-red-200';
                    statusDot = 'bg-red-600';
                  } else if (product.stock <= product.minStock) {
                    stockStatus = 'Stock Crítico';
                    statusColor = 'bg-amber-100 text-amber-800 border-amber-200';
                    statusDot = 'bg-amber-500';
                  }

                  return (
                    <tr key={product.id} className="hover:bg-slate-50 transition-colors group">
                      <td className="px-6 py-4 text-xs font-mono font-semibold text-on-surface-variant">{product.code}</td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg bg-slate-100 overflow-hidden border border-outline-variant/50 shrink-0">
                            <img className="w-full h-full object-cover" alt={product.name} src={product.image} referrerPolicy="no-referrer" />
                          </div>
                          <span className="text-xs font-bold text-on-surface font-sans">{product.name}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-xs font-semibold text-on-surface-variant font-sans">{product.category}</td>
                      <td className="px-6 py-4 text-xs font-semibold text-on-surface-variant font-sans">
                        {product.supplier || 'Proveedor Local'}
                      </td>
                      <td className="px-6 py-4 text-right text-xs font-extrabold text-on-surface font-sans">${product.price.toFixed(2)}</td>
                      <td className="px-6 py-4 text-center text-xs font-extrabold text-on-surface font-sans">
                        {product.stock} <span className="text-[10px] text-on-surface-variant/70 font-normal">/ {product.maxStock || 100}</span>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`px-2.5 py-1 rounded-full text-[9px] font-extrabold uppercase tracking-wider border flex items-center gap-1.5 w-fit ${statusColor}`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${statusDot}`}></span>
                          <span>{stockStatus}</span>
                        </span>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex justify-end gap-1 text-on-surface-variant">
                          <button
                            onClick={() => handleOpenEditModal(product)}
                            className="p-1.5 text-on-surface-variant hover:text-primary hover:bg-primary/5 rounded-md transition-all cursor-pointer"
                            title="Editar"
                          >
                            <span className="material-symbols-outlined text-[18px]">edit</span>
                          </button>
                          <button
                            onClick={() => {
                              if (confirm(`¿Estás seguro de que deseas eliminar ${product.name} de tu inventario?`)) {
                                onDeleteProduct(product.id);
                              }
                            }}
                            className="p-1.5 text-on-surface-variant hover:text-error hover:bg-error/5 rounded-md transition-all cursor-pointer"
                            title="Eliminar"
                          >
                            <span className="material-symbols-outlined text-[18px]">delete</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Product Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/65 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-[24px] max-w-md w-full p-6 border border-outline-variant shadow-2xl relative animate-in fade-in zoom-in-95 duration-200">
            <div className="flex justify-between items-center mb-5">
              <h3 className="text-sm font-bold text-on-surface font-sans">Registrar Producto de Inventario</h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="w-8 h-8 rounded-full hover:bg-surface-container flex items-center justify-center text-on-surface-variant transition-colors cursor-pointer"
              >
                <span className="material-symbols-outlined text-[18px]">close</span>
              </button>
            </div>

            <form onSubmit={handleCreateProduct} className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1.5 font-sans">
                  Nombre del Producto
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ej. Café Durán Moledero 200g"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="w-full bg-surface-container-low border border-outline-variant/60 rounded-xl py-2 px-3 text-xs focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none font-sans text-on-surface"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1.5 font-sans">
                    Código SKU (Autogenerado o Manual)
                  </label>
                  <input
                    type="text"
                    required
                    value={code}
                    onChange={e => setCode(e.target.value)}
                    className="w-full bg-surface-container-low border border-outline-variant/60 rounded-xl py-2 px-3 text-xs focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none font-sans text-on-surface"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1.5 font-sans">
                    Categoría
                  </label>
                  <select
                    value={category}
                    onChange={e => setCategory(e.target.value)}
                    className="w-full bg-surface-container-low border border-outline-variant/60 rounded-xl py-2.5 px-3 text-xs focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none font-sans text-on-surface"
                  >
                    <option value="Granos y Abarrotes">Granos y Abarrotes</option>
                    <option value="Lácteos y Quesos">Lácteos y Quesos</option>
                    <option value="Bebidas">Bebidas</option>
                    <option value="Snacks">Snacks</option>
                    <option value="Limpieza">Limpieza</option>
                    <option value="Electrónicos">Electrónicos</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1.5 font-sans">
                    Precio Balboas/Dólares ($)
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    placeholder="0.00"
                    value={price || ''}
                    onChange={e => setPrice(parseFloat(e.target.value) || 0)}
                    className="w-full bg-surface-container-low border border-outline-variant/60 rounded-xl py-2 px-3 text-xs focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none font-sans text-on-surface"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1.5 font-sans">
                    Proveedor
                  </label>
                  <input
                    type="text"
                    placeholder="Ej. Distribuidora Central"
                    value={supplier}
                    onChange={e => setSupplier(e.target.value)}
                    className="w-full bg-surface-container-low border border-outline-variant/60 rounded-xl py-2 px-3 text-xs focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none font-sans text-on-surface"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1.5 font-sans">
                    Stock Inicial
                  </label>
                  <input
                    type="number"
                    required
                    placeholder="0"
                    value={stock || ''}
                    onChange={e => setStock(parseInt(e.target.value) || 0)}
                    className="w-full bg-surface-container-low border border-outline-variant/60 rounded-xl py-2 px-3 text-xs focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none font-sans text-on-surface"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1.5 font-sans">
                    Stock Mínimo
                  </label>
                  <input
                    type="number"
                    required
                    placeholder="10"
                    value={minStock || ''}
                    onChange={e => setMinStock(parseInt(e.target.value) || 0)}
                    className="w-full bg-surface-container-low border border-outline-variant/60 rounded-xl py-2 px-3 text-xs focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none font-sans text-on-surface"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1.5 font-sans">
                    Stock Máximo
                  </label>
                  <input
                    type="number"
                    required
                    placeholder="100"
                    value={maxStock || ''}
                    onChange={e => setMaxStock(parseInt(e.target.value) || 0)}
                    className="w-full bg-surface-container-low border border-outline-variant/60 rounded-xl py-2 px-3 text-xs focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none font-sans text-on-surface"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1.5 font-sans">
                  URL de Imagen (Opcional)
                </label>
                <input
                  type="text"
                  placeholder="https://..."
                  value={image}
                  onChange={e => setImage(e.target.value)}
                  className="w-full bg-surface-container-low border border-outline-variant/60 rounded-xl py-2 px-3 text-xs focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none font-sans text-on-surface"
                />
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-outline-variant/40 mt-5">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl text-xs font-bold font-sans text-on-surface-variant cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-primary hover:bg-primary-container text-white rounded-xl text-xs font-bold font-sans shadow-md"
                >
                  Registrar Ítems
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Product Modal */}
      {showEditModal && editingProduct && (
        <div className="fixed inset-0 z-50 bg-black/65 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-[24px] max-w-md w-full p-6 border border-outline-variant shadow-2xl relative animate-in fade-in zoom-in-95 duration-200">
            <div className="flex justify-between items-center mb-5">
              <h3 className="text-sm font-bold text-on-surface font-sans">Editar Producto de Catálogo</h3>
              <button
                onClick={() => {
                  setShowEditModal(false);
                  setEditingProduct(null);
                }}
                className="w-8 h-8 rounded-full hover:bg-surface-container flex items-center justify-center text-on-surface-variant transition-colors cursor-pointer"
              >
                <span className="material-symbols-outlined text-[18px]">close</span>
              </button>
            </div>

            <form onSubmit={handleSaveEditProduct} className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1.5 font-sans">
                  Nombre del Producto
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="w-full bg-surface-container-low border border-outline-variant/60 rounded-xl py-2 px-3 text-xs focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none font-sans text-on-surface font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1.5 font-sans">
                    Código SKU
                  </label>
                  <input
                    type="text"
                    required
                    value={code}
                    onChange={e => setCode(e.target.value)}
                    className="w-full bg-surface-container-low border border-outline-variant/60 rounded-xl py-2 px-3 text-xs focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none font-sans text-on-surface"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1.5 font-sans">
                    Categoría
                  </label>
                  <select
                    value={category}
                    onChange={e => setCategory(e.target.value)}
                    className="w-full bg-surface-container-low border border-outline-variant/60 rounded-xl py-2.5 px-3 text-xs focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none font-sans text-on-surface"
                  >
                    <option value="Granos y Abarrotes">Granos y Abarrotes</option>
                    <option value="Lácteos y Quesos">Lácteos y Quesos</option>
                    <option value="Bebidas">Bebidas</option>
                    <option value="Snacks">Snacks</option>
                    <option value="Limpieza">Limpieza</option>
                    <option value="Electrónicos">Electrónicos</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1.5 font-sans">
                    Precio ($)
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={price}
                    onChange={e => setPrice(parseFloat(e.target.value) || 0)}
                    className="w-full bg-surface-container-low border border-outline-variant/60 rounded-xl py-2 px-3 text-xs focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none font-sans text-on-surface font-bold"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1.5 font-sans">
                    Proveedor
                  </label>
                  <input
                    type="text"
                    value={supplier}
                    onChange={e => setSupplier(e.target.value)}
                    className="w-full bg-surface-container-low border border-outline-variant/60 rounded-xl py-2 px-3 text-xs focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none font-sans text-on-surface"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1.5 font-sans">
                    Stock
                  </label>
                  <input
                    type="number"
                    required
                    value={stock}
                    onChange={e => setStock(parseInt(e.target.value) || 0)}
                    className="w-full bg-surface-container-low border border-outline-variant/60 rounded-xl py-2 px-3 text-xs focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none font-sans text-on-surface"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1.5 font-sans">
                    Stock Mínimo
                  </label>
                  <input
                    type="number"
                    required
                    value={minStock}
                    onChange={e => setMinStock(parseInt(e.target.value) || 0)}
                    className="w-full bg-surface-container-low border border-outline-variant/60 rounded-xl py-2 px-3 text-xs focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none font-sans text-on-surface"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1.5 font-sans">
                    Stock Máximo
                  </label>
                  <input
                    type="number"
                    required
                    value={maxStock}
                    onChange={e => setMaxStock(parseInt(e.target.value) || 0)}
                    className="w-full bg-surface-container-low border border-outline-variant/60 rounded-xl py-2 px-3 text-xs focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none font-sans text-on-surface"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-on-surface-variant uppercase tracking-wider mb-1.5 font-sans">
                  URL de Imagen
                </label>
                <input
                  type="text"
                  value={image}
                  onChange={e => setImage(e.target.value)}
                  className="w-full bg-surface-container-low border border-outline-variant/60 rounded-xl py-2 px-3 text-xs focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none font-sans text-on-surface"
                />
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-outline-variant/40 mt-5">
                <button
                  type="button"
                  onClick={() => {
                    setShowEditModal(false);
                    setEditingProduct(null);
                  }}
                  className="px-4 py-2 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl text-xs font-bold font-sans text-on-surface-variant cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-primary hover:bg-primary-container text-white rounded-xl text-xs font-bold font-sans shadow-md"
                >
                  Guardar Cambios
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
