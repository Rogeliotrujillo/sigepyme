import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Screen, TransitionType, Product, Customer, Transaction, UserRole, CompanyConfig } from './types';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import POS from './components/POS';
import Customers from './components/Customers';
import Inventory from './components/Inventory';
import Login from './components/Login';
import Reports from './components/Reports';
import Settings from './components/Settings';

// Mock users for roles assignment (Admin, Gerente, Vendedor)
const initialUsers: UserRole[] = [
  { id: 'u-1', username: 'admin', name: 'Sofía Montenegro', role: 'Admin', active: true },
  { id: 'u-2', username: 'gerente', name: 'Carlos Ortega', role: 'Gerente', active: true },
  { id: 'u-3', username: 'vendedor', name: 'Esteban Córdoba', role: 'Vendedor', active: true },
];

// Initial Company & Billing configuration
const initialCompanyConfig: CompanyConfig = {
  name: 'Mini Super El Porvenir',
  ruc: '15562234-2-2026 DV 45',
  phone: '+507 264-5566',
  email: 'contacto@porvenir.pa',
  address: 'Vía España, Bella Vista, Edificio El Porvenir, Local 2A, Ciudad de Panamá',
  itbmsRate: 7, // 7% ITBMS standard
  invoicePrefix: 'INV-88',
  invoiceSequence: 32,
};

// Initial Products list aligned with Spanish categories
const initialProducts: Product[] = [
  {
    id: 'p-1',
    name: 'Café Durán Tradicional 1lb',
    code: 'PD-012',
    category: 'Granos y Abarrotes',
    price: 5.85,
    stock: 12,
    minStock: 10,
    maxStock: 80,
    supplier: 'Café Durán S.A.',
    image: 'https://images.unsplash.com/photo-1559056199-641a0ac8b55e?auto=format&fit=crop&q=80&w=150',
    demand: 'Alta Demanda'
  },
  {
    id: 'p-2',
    name: 'Arroz Especial Pelín 5lb',
    code: 'PD-098',
    category: 'Granos y Abarrotes',
    price: 3.25,
    stock: 5,
    minStock: 20,
    maxStock: 120,
    supplier: 'Distribuidora Pelín Panamá',
    image: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&q=80&w=150',
    demand: 'Bajo Stock'
  },
  {
    id: 'p-3',
    name: 'Agua Brisa Mineral 500ml',
    code: 'PD-044',
    category: 'Bebidas',
    price: 0.85,
    stock: 8,
    minStock: 15,
    maxStock: 200,
    supplier: 'Coca-Cola FEMSA Panamá',
    image: 'https://images.unsplash.com/photo-1608885898957-a599fb1b1a44?auto=format&fit=crop&q=80&w=150',
    demand: 'Bajo Stock'
  },
  {
    id: 'p-4',
    name: 'Leche Estrella Entera 1L',
    code: 'PD-102',
    category: 'Lácteos y Quesos',
    price: 1.65,
    stock: 45,
    minStock: 15,
    maxStock: 100,
    supplier: 'Estrella Azul S.A.',
    image: 'https://images.unsplash.com/photo-1550583724-b2692b85b150?auto=format&fit=crop&q=80&w=150',
    demand: 'Normal'
  },
  {
    id: 'p-5',
    name: 'Queso Amarillo Kraft 12 Slices',
    code: 'PD-108',
    category: 'Lácteos y Quesos',
    price: 2.95,
    stock: 22,
    minStock: 8,
    maxStock: 60,
    supplier: 'Kraft Foods Central',
    image: 'https://images.unsplash.com/photo-1486299267070-8382e214439b?auto=format&fit=crop&q=80&w=150',
    demand: 'Normal'
  },
  {
    id: 'p-6',
    name: 'Papitas Lays Original Familiar',
    code: 'PD-220',
    category: 'Snacks',
    price: 1.95,
    stock: 65,
    minStock: 12,
    maxStock: 100,
    supplier: 'PepsiCo Alimentos Panamá',
    image: 'https://images.unsplash.com/photo-1599490659213-e2b9527bb087?auto=format&fit=crop&q=80&w=150',
    demand: 'Alta Demanda'
  },
  {
    id: 'p-7',
    name: 'Desinfectante Clorox Original 1L',
    code: 'PD-305',
    category: 'Limpieza',
    price: 2.10,
    stock: 18,
    minStock: 6,
    maxStock: 50,
    supplier: 'Clorox de Panamá S.A.',
    image: 'https://images.unsplash.com/photo-1583947215259-38e31be8751f?auto=format&fit=crop&q=80&w=150',
    demand: 'Normal'
  },
  {
    id: 'p-8',
    name: 'Cargador Rápido USB-C 20W',
    code: 'PD-882',
    category: 'Electrónicos',
    price: 12.99,
    stock: 32,
    minStock: 5,
    maxStock: 40,
    supplier: 'Tech Logistics Latam',
    image: 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?auto=format&fit=crop&q=80&w=150',
    demand: 'Normal'
  }
];

// Initial Customers in Spanish
const initialCustomers: Customer[] = [
  {
    id: 'c-1',
    name: 'Alejandro Morales',
    cedula: '8-842-1234',
    phone: '+507 6234-5678',
    email: 'amorales@email.pa',
    totalSpent: 425.20,
    visits: 24,
    averageTicket: 17.71,
    location: 'San Francisco, Ciudad de Panamá',
    frequentItems: [
      { name: 'Café Durán Tradicional', detail: 'Granos y Abarrotes', isTop: true },
      { name: 'Leche Entera 1L', detail: 'Lácteos' }
    ],
    purchaseHistory: [
      { date: '04 Jul 2026', invoice: 'INV-8830', amount: 15.20, category: 'Abarrotes', extraItemsCount: 2 },
      { date: '28 Jun 2026', invoice: 'INV-8821', amount: 8.50, category: 'Lácteos' }
    ],
    status: 'VIP'
  },
  {
    id: 'c-2',
    name: 'María Castillo',
    cedula: '4-112-987',
    phone: '+507 6555-1212',
    email: 'mcastillo@porvenir.pa',
    totalSpent: 189.50,
    visits: 12,
    averageTicket: 15.79,
    location: 'Bella Vista, Ciudad de Panamá',
    frequentItems: [
      { name: 'Arroz Especial 5lb', detail: 'Granos y Abarrotes', isTop: true },
      { name: 'Queso Amarillo', detail: 'Lácteos' }
    ],
    purchaseHistory: [
      { date: '02 Jul 2026', invoice: 'INV-8828', amount: 24.15, category: 'Abarrotes' }
    ],
    status: 'VIP'
  },
  {
    id: 'c-3',
    name: 'Esteban Ortega',
    cedula: '8-755-432',
    phone: '+507 6888-7766',
    email: 'eortega@constructora.pa',
    totalSpent: 312.00,
    visits: 8,
    averageTicket: 39.00,
    location: 'La Chorrera, Panamá Oeste',
    frequentItems: [
      { name: 'Clorox Original 1L', detail: 'Limpieza', isTop: true }
    ],
    purchaseHistory: [
      { date: '15 Jun 2026', invoice: 'INV-8812', amount: 41.20, category: 'Limpieza' }
    ],
    status: 'Deuda Pendiente'
  }
];

// Initial Transactions (Mocked)
const initialTransactions: Transaction[] = [
  {
    id: 'INV-8829',
    customerName: 'Ricardo Castillo',
    customerInitials: 'RC',
    date: '08 Jul, 11:45 AM',
    amount: 15.85,
    paymentMethod: 'Yappy',
    status: 'Completado'
  },
  {
    id: 'INV-8830',
    customerName: 'Alejandro Morales',
    customerInitials: 'AM',
    date: '08 Jul, 10:30 AM',
    amount: 15.20,
    paymentMethod: 'Efectivo',
    status: 'Completado'
  },
  {
    id: 'INV-8831',
    customerName: 'Jorge Pérez',
    customerInitials: 'JP',
    date: '08 Jul, 09:15 AM',
    amount: 22.40,
    paymentMethod: 'Tarjeta',
    status: 'Completado'
  }
];

// Navigation spec transition rules
const getTransition = (current: Screen, target: Screen): TransitionType => {
  if (current === 'customers') {
    if (target === 'dashboard') return 'push_back';
    if (target === 'inventory') return 'none';
    if (target === 'pos') return 'none';
  }
  if (current === 'dashboard') {
    if (target === 'inventory') return 'push';
    if (target === 'pos') return 'push';
    if (target === 'customers') return 'push';
    if (target === 'reports') return 'push';
    if (target === 'settings') return 'push';
  }
  if (current === 'inventory') {
    if (target === 'dashboard') return 'push_back';
    if (target === 'pos') return 'none';
    if (target === 'customers') return 'none';
  }
  if (current === 'pos') {
    if (target === 'dashboard') return 'push_back';
    if (target === 'inventory') return 'none';
    if (target === 'customers') return 'none';
  }
  return 'none';
};

export default function App() {
  const [currentUser, setCurrentUser] = useState<UserRole | null>(null);
  const [users, setUsers] = useState<UserRole[]>(initialUsers);
  const [companyConfig, setCompanyConfig] = useState<CompanyConfig>(initialCompanyConfig);

  const [currentScreen, setCurrentScreen] = useState<Screen>('login');
  const [transitionType, setTransitionType] = useState<TransitionType>('none');
  
  const [products, setProducts] = useState<Product[]>(initialProducts);
  const [customers, setCustomers] = useState<Customer[]>(initialCustomers);
  const [transactions, setTransactions] = useState<Transaction[]>(initialTransactions);

  const handleLoginSuccess = (user: UserRole) => {
    setCurrentUser(user);
    // Vendedores land on POS directly, others on Dashboard
    if (user.role === 'Vendedor') {
      setCurrentScreen('pos');
    } else {
      setCurrentScreen('dashboard');
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setCurrentScreen('login');
    setTransitionType('none');
  };

  const handleNavigate = (target: Screen, forcedTransition?: TransitionType) => {
    // Check role access
    if (currentUser && currentUser.role === 'Vendedor' && ['inventory', 'reports', 'settings'].includes(target)) {
      alert('Acceso Denegado: Su cuenta con rol de Vendedor no tiene permisos para acceder a este módulo.');
      return;
    }

    const transition = forcedTransition ?? getTransition(currentScreen, target);
    setTransitionType(transition);
    setCurrentScreen(target);
  };

  const handleAddTransaction = (newTx: Transaction) => {
    setTransactions([newTx, ...transactions]);
  };

  const handleUpdateProductStock = (id: string, delta: number) => {
    setProducts(prevProducts =>
      prevProducts.map(p =>
        p.id === id ? { ...p, stock: Math.max(0, p.stock + delta) } : p
      )
    );
  };

  const handleAddProduct = (newProduct: Product) => {
    setProducts([newProduct, ...products]);
  };

  const handleDeleteProduct = (id: string) => {
    setProducts(products.filter(p => p.id !== id));
  };

  const handleUpdateProduct = (updatedProduct: Product) => {
    setProducts(products.map(p => p.id === updatedProduct.id ? updatedProduct : p));
  };

  const handleAddCustomer = (newCustomer: Customer) => {
    setCustomers([newCustomer, ...customers]);
  };

  // Settings Actions
  const handleUpdateCompanyConfig = (newConfig: CompanyConfig) => {
    setCompanyConfig(newConfig);
  };

  const handleAddUser = (newUser: Omit<UserRole, 'id'>) => {
    const userWithId: UserRole = {
      ...newUser,
      id: `u-${Date.now()}`,
    };
    setUsers([...users, userWithId]);
  };

  const handleToggleUserStatus = (id: string) => {
    setUsers(users.map(u => u.id === id ? { ...u, active: !u.active } : u));
  };

  const handleUpdateUserRole = (id: string, role: 'Admin' | 'Gerente' | 'Vendedor') => {
    setUsers(users.map(u => u.id === id ? { ...u, role } : u));
  };

  const handleIncrementInvoiceSequence = () => {
    setCompanyConfig(prev => ({
      ...prev,
      invoiceSequence: prev.invoiceSequence + 1
    }));
  };

  const handleUpdateCustomerSpent = (id: string, amount: number) => {
    setCustomers(prev => prev.map(c => {
      if (c.id === id) {
        const newTotalSpent = c.totalSpent + amount;
        const newVisits = c.visits + 1;
        const newAverage = newTotalSpent / newVisits;
        return {
          ...c,
          totalSpent: newTotalSpent,
          visits: newVisits,
          averageTicket: newAverage,
          status: newTotalSpent > 250 ? 'VIP' : c.status
        };
      }
      return c;
    }));
  };

  // Slide-in spring animations variants
  const animationVariants = {
    initial: (type: TransitionType) => {
      if (type === 'push') {
        return { x: '100vw', y: 0, opacity: 0.9 };
      }
      if (type === 'push_back') {
        return { x: '-100vw', y: 0, opacity: 0.9 };
      }
      if (type === 'slide_up') {
        return { x: 0, y: '100vh', opacity: 0.9 };
      }
      return { x: 0, y: 0, opacity: 1 };
    },
    animate: {
      x: 0,
      y: 0,
      opacity: 1,
      transition: {
        type: 'spring',
        stiffness: 260,
        damping: 30,
        mass: 1,
      },
    },
    exit: (type: TransitionType) => {
      if (type === 'push') {
        return { x: '-100vw', opacity: 0.8, transition: { duration: 0.3 } };
      }
      if (type === 'push_back') {
        return { x: '100vw', opacity: 0.8, transition: { duration: 0.3 } };
      }
      if (type === 'slide_up') {
        return { y: '-100vh', opacity: 0.8, transition: { duration: 0.3 } };
      }
      return { opacity: 0, transition: { duration: 0 } };
    },
  };

  // Render Login screen if no active session
  if (!currentUser) {
    return <Login onLoginSuccess={handleLoginSuccess} availableUsers={users} />;
  }

  return (
    <div className="bg-slate-50 text-on-background font-sans min-h-screen">
      {/* Shared Sidebar */}
      <Sidebar currentScreen={currentScreen} onNavigate={handleNavigate} onLogout={handleLogout} currentUser={currentUser} />

      {/* Main Panel Wrapper offset left by 64 (the sidebar width) */}
      <div className="pl-64 min-h-screen flex flex-col">
        {/* Fixed Top Navigation Bar */}
        <Header currentScreen={currentScreen} onNavigate={handleNavigate} currentUser={currentUser} onLogout={handleLogout} />

        {/* Dynamic Page Stage Container offset top by 16 (64px) for fixed header */}
        <main className="mt-16 p-10 flex-grow relative overflow-hidden">
          <AnimatePresence mode="wait" custom={transitionType}>
            <motion.div
              key={currentScreen}
              custom={transitionType}
              variants={animationVariants}
              initial="initial"
              animate="animate"
              exit="exit"
              className="w-full h-full"
            >
              {currentScreen === 'dashboard' && (
                <Dashboard
                  onNavigate={handleNavigate}
                  transactions={transactions}
                  onAddTransactionClick={() => handleNavigate('pos', 'slide_up')}
                />
              )}

              {currentScreen === 'pos' && (
                <POS
                  products={products}
                  customers={customers}
                  companyConfig={companyConfig}
                  currentUser={currentUser}
                  onNavigate={handleNavigate}
                  onAddTransaction={handleAddTransaction}
                  onUpdateProductStock={handleUpdateProductStock}
                  onAddCustomer={handleAddCustomer}
                  onIncrementInvoiceSequence={handleIncrementInvoiceSequence}
                  onUpdateCustomerSpent={handleUpdateCustomerSpent}
                />
              )}

              {currentScreen === 'customers' && (
                <Customers
                  customers={customers}
                  onNavigate={handleNavigate}
                  onAddCustomer={handleAddCustomer}
                />
              )}

              {currentScreen === 'inventory' && (
                <Inventory
                  products={products}
                  onNavigate={handleNavigate}
                  onAddProduct={handleAddProduct}
                  onDeleteProduct={handleDeleteProduct}
                  onUpdateProduct={handleUpdateProduct}
                />
              )}

              {currentScreen === 'reports' && (
                <Reports
                  transactions={transactions}
                  products={products}
                  customers={customers}
                  onNavigate={handleNavigate}
                />
              )}

              {currentScreen === 'settings' && (
                <Settings
                  companyConfig={companyConfig}
                  onUpdateCompanyConfig={handleUpdateCompanyConfig}
                  users={users}
                  onAddUser={handleAddUser}
                  onToggleUserStatus={handleToggleUserStatus}
                  onUpdateUserRole={handleUpdateUserRole}
                  currentUser={currentUser}
                />
              )}
            </motion.div>
          </AnimatePresence>
        </main>

        {/* Footer */}
        <footer className="px-10 py-5 border-t border-outline-variant/60 text-xs text-on-surface-variant font-medium flex justify-between items-center bg-white">
          <p>© 2026 SIGE-PYME Gestión Empresarial Panamá. Todos los derechos reservados.</p>
          <div className="flex gap-6">
            <a href="#" onClick={(e) => { e.preventDefault(); alert('Cargando términos de servicio...'); }} className="hover:text-primary hover:underline transition-colors">Términos de Uso</a>
            <a href="#" onClick={(e) => { e.preventDefault(); alert('Cargando políticas de privacidad...'); }} className="hover:text-primary hover:underline transition-colors">Privacidad de Datos</a>
            <a href="#" onClick={(e) => { e.preventDefault(); alert('Iniciando ticket de soporte técnico...'); }} className="hover:text-primary hover:underline transition-colors">Soporte Técnico</a>
          </div>
        </footer>
      </div>
    </div>
  );
}
